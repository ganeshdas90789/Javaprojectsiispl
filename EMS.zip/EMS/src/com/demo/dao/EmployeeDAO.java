package com.demo.dao;

import java.util.Scanner;

import com.demo.pojo.Employee;

public class EmployeeDAO {
	private Employee emparr[];
	Scanner sc;
	
	public EmployeeDAO()
	{
		sc=new Scanner(System.in);
	}
	public void insert()
	{
		System.out.println("Enter no. of employee you want to have:");
		int noofemployee=sc.nextInt();
		emparr=new Employee[noofemployee];
		for(int x=0;x<emparr.length;x++)
		{
			emparr[x]=new Employee();
			System.out.println("Enter employee id:");
			emparr[x].setEmpid(sc.nextInt());
			System.out.println("Enter employee name:");
			emparr[x].setEmpname(sc.next());
			System.out.println("Enter salary:");
			emparr[x].setSalary(sc.nextDouble());
			
		}
	}
	public void display()
	{
		for(Employee e:emparr)
		{
			if(e!=null) {
			System.out.println("Employee id is:" + " " + e.getEmpid());
			System.out.println("Employee name is:" + " " + e.getEmpname());
			System.out.println("Employee salary is:" + " " + e.getSalary());
			}
		}
	}
	public void delete()
	{
		System.out.println("Enter employee id which u want to delete:");
		int empid=sc.nextInt();
		Employee edelete=null;
		int val=0;
		
		for(int x=0;x<emparr.length;x++)
		{
			if(emparr[x].getEmpid()==empid)
			{
				emparr[x]=null;
			}
		}
	}
	public void update()
	{
		System.out.println("Enter employee id which u want to update");
		int empid=sc.nextInt();
		for(Employee e:emparr)
		{
			
		}
	}

}
