package com.demo.service;

import com.demo.dao.EmployeeDAO;

public class EmployeeService {
	private EmployeeDAO empdao;
	public EmployeeService()
	{
		empdao=new EmployeeDAO();
	}
	public void insertDetails()
	{
		empdao.insert();
	}
	public void show()
	{
		empdao.display();
	}
	public void show1()
	{
		empdao.delete();
	}
	public void show2()
	{
		empdao.update();
	}

}
