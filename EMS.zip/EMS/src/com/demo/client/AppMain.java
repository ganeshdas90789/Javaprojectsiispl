package com.demo.client;

import com.demo.menu.Menu;

public class AppMain {
	public static void main(String args[])

	{
		Menu m1=new Menu();
		m1.displayMenu();
		
	}

}
