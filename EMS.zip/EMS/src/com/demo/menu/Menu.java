package com.demo.menu;
import java.util.Scanner;

import com.demo.service.EmployeeService;
public class Menu {
	Scanner sc;
	EmployeeService empservice;
	public Menu()
	{
		empservice=new EmployeeService();
		
	}
	public void displayMenu()
	{
		sc=new Scanner(System.in);
		String choice="Y";
		int ch=0;
		while(choice.equals("Y"))
		{
			System.out.println("Enter your choice:");
			System.out.println("1. insert Employee");
			System.out.println("2. Delete Employee");
			System.out.println("3. Update Employee");
			System.out.println("4. View Employee");
			System.out.println("5. Exit");
			
			ch=sc.nextInt();
			
			switch(ch)
			{
			case 1:
				empservice.insertDetails();
				break;
			case 2:
				empservice.show1();
				break;
			case 3:
				empservice.show2();
				break;
			case 4:
				empservice.show();
				break;
			case 5:
				System.exit(0);
			}
		
			System.out.println("Do you want to continue(Y/N):");
			
			choice=sc.next();
		}
	
	}

}
