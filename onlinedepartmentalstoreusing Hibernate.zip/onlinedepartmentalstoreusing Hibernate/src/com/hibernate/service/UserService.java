package com.hibernate.service;

import com.hibernate.dao.StoreUser;

public class UserService {
	

	private StoreUser su;
	
	public UserService()
	{
		su=new StoreUser();
		
	}
	
	public void insert()
	{
		su.userStore();
	}
	public void check()
	{
		su.checkAdmin();
	}
	public void checkUser1()
	{
		su.checkUser();
	}

}
