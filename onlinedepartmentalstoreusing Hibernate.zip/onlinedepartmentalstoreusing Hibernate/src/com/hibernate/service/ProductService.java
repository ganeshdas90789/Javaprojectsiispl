package com.hibernate.service;

import com.Entity.User;
import com.hibernate.dao.StoreProduct;

public class ProductService {
	
	private StoreProduct sp;
	
	public ProductService()
	{
		sp=new StoreProduct();
	}
	
	public void insertProduct(User u)
	{
		sp.productStore(u);
	}
	public void display()
	{
		sp.viewProduct();
	}
	public void Calculate()
	{
		sp.calculateSellingPrice();
	}
	public void View()
	{
		sp.viewById();
	}
	public void view1()
	{
		sp.viewByCat();
	}
	public void Search()
	{
		sp.SearchByName();
	}
	public void total()
	{
		sp.calculateTotal();
	}
	public void profit()
	{
		sp.CalculateProfit();
	}
	public void Buying()
	{
		sp.BuyProduct();
	}
	public void bill1()
	{
		sp.bill();
	}
	public void Filter()
	{
		sp.FilterByprice();
	}
	public void filter1()
	{
		sp.FilterByCategory();
	}

}
