package com.hibernate.Main;

import com.hibernate.menu.UserMenu;




public class AppMain {

	
	
	
	
	public static void main(String args[])
	{
		UserMenu umenu=new UserMenu();
		umenu.displayMenu();
		
	}

}
