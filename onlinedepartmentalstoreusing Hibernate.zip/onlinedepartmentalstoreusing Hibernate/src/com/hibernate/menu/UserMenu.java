package com.hibernate.menu;

import java.util.Scanner;

import com.hibernate.service.UserService;
import org.hibernate.*;
import org.hibernate.cfg.Configuration;

public class UserMenu {
	
	private Scanner sc;
	private UserService us;
	private SessionFactory sesfact;
	private Session session;
	
	public UserMenu()
	{
		sc=new Scanner(System.in);
		sesfact=new Configuration().configure("Hibernate.cfg.xml").buildSessionFactory();
		us=new UserService();
	}
	
	public void displayMenu()
	{
		String ch="y";
		int choice=0;
		
		while(ch.equals("y"))
		{
			System.out.println("Enter choice:");
			System.out.println("1. Register");
			System.out.println("2. login as user");
			System.out.println("3. login as Admin");
			System.out.println("4. exit");
			
			choice=sc.nextInt();
			
			
			
			switch(choice)
			{
			case 1:
				us.insert();
			       
				break;
			case 2:us.checkUser1();
				break;
			case 3:us.check();
			    break;
			case 4:
				System.exit(0);
			 
			
			}
			System.out.println("do you want to continue(y/n):");
			ch=sc.next();

			}
	}

}
