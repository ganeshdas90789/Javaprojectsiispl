package com.hibernate.dao;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.Entity.Product;
import com.Entity.User;

public class StoreProduct {
	
	private Session sess;
	private SessionFactory sesfact;
	private Transaction tx;
	private Scanner sc;
	private Set<Product> pset;
	private  List<Product> buyinglist;
	
	
	public StoreProduct()
	{
		sesfact=new Configuration().configure("Hibernate.cfg.xml").buildSessionFactory();
		sc=new Scanner(System.in);
		pset=new HashSet<>();
		buyinglist=new ArrayList<>();
		
	}
	
	public void productStore(User u)
	{
		sess=sesfact.openSession();
		tx=sess.beginTransaction();
		
		
		System.out.println("Enter no.of Products:");
		int noofproducts=sc.nextInt();
		for(int i=0;i<noofproducts;i++)
		{
			Product p=new Product();
			System.out.println("Enter the product id:");
			p.setProductid(sc.nextInt());
			
			System.out.println("Enter the item name:");
			p.setItemname(sc.next());
			System.out.println("Enter the product name:");
			p.setProductname(sc.next());
			System.out.println("Enter the category:");
			p.setCategory(sc.next());
			System.out.println("Enter the buying price:");
			double price=sc.nextDouble();
			p.setBuyingPrice(price);
			p.setSellingprice(price);
		    System.out.println("Enter quantity:");
		    p.setQuantity(sc.nextInt());
		    pset.add(p);
		    u.setProductset(pset);
		    p.setUobj(u);
		   
		  
		  sess.save(p);
			
		}
		tx.commit();
		
		
	}
	
	public void viewProduct()
	{
		sess=sesfact.openSession();
		
		
		org.hibernate.query.Query ql=sess.createQuery("from Product p");
		List<Product> plist=ql.getResultList();
		for(Product p:plist)
		{
			System.out.println(p.getItemname());
			System.out.println(p.getProductname());
			System.out.println(p.getCategory());
			System.out.println(p.getBuyingPrice());
			
			
		}
		
		
		
		
	
		
	}
	
	public void calculateSellingPrice()
	{
		sess=sesfact.openSession();
		
		
		org.hibernate.query.Query ql=sess.createQuery(" from  Product");
		List<Product> plist=ql.getResultList();
		for(Product p:plist)
		{
			System.out.println(p.getSellingprice());
		}
		
	}
	public void viewById()
	{
		sess=sesfact.openSession();
		
		
		System.out.println("Enter product id:");
		int pid=sc.nextInt();
		org.hibernate.query.Query ql=sess.createQuery("select p from Product p where productid=:id");
		ql.setParameter("id", pid);
		List<Product> plist=ql.getResultList();
		for(Product p:plist)
		{
			System.out.println(p.getProductname());
		}

		
	}
	public void viewByCat()
	{
		sess=sesfact.openSession();
		
		
		System.out.println("Enter item category:");
		String cat=sc.next();
		org.hibernate.query.Query ql=sess.createQuery("select p from Product p where category=:Cat");
		ql.setParameter("Cat", cat);
		List<Product> plist=ql.getResultList();
		for(Product p:plist)
		{
			System.out.println(p.getItemname());
			System.out.println(p.getProductname());
		}

		
	}
	public void SearchByName()
	{
		sess=sesfact.openSession();
		
		
		System.out.println("Enter the name of product:");
		String pname=sc.next();
		
		org.hibernate.query.Query ql=sess.createQuery("select p from Product p where productname=:name");
		ql.setParameter("name", pname);
		
		List<Product> plist=ql.getResultList();
		for(Product p:plist)
		{
			
			System.out.println(p.getProductname());
		}
		
		
		
	}
	 
	public void calculateTotal()
	{
		
		sess=sesfact.openSession();
		
		org.hibernate.query.Query ql=sess.createQuery("select sum(p.Sellingprice) from Product p ");
		List<Product> plist=ql.getResultList();
		System.out.println(plist);
		//System.out.println(total);
		
	}
	
	public void CalculateProfit()
	{
		double profit=0;
		sess=sesfact.openSession();
		
		
		org.hibernate.query.Query ql=sess.createQuery(" from Product ");
		List<Product>plist=ql.list();
		for(Product p:plist)
		{
			
			profit=profit+(p.getSellingprice()-p.getBuyingPrice());
		
		}
		System.out.println(profit);
	}
	
	public void BuyProduct()
	{
		sess=sesfact.openSession();
		
		org.hibernate.query.Query ql=sess.createQuery("from Product p");
		List<Product> plist1=ql.getResultList();
		for(Product p:plist1)
		{
			System.out.println("product name:" + p.getProductname());
			System.out.println("price is:"+ p.getSellingprice());
			System.out.println("quantity is:" + p.getQuantity());
			
		}
		String choice="y";
		while(choice.equals("y"))
		{
		
		System.out.println("Enter the product name which u want to buy:");
		String pname=sc.next();
		org.hibernate.query.Query q=sess.createQuery("select p from Product p where p.productname=:name");
		q.setParameter("name", pname);
		List<Product> plist2=q.list();
		for(Product p:plist2)
		{
			p.getSellingprice();
			p.getProductname();
			buyinglist.add(p);
			System.out.println("Product added");
		}
		System.out.println("do you wantto continue(y/n):");
		choice=sc.next();
		
		}
		bill();
	}
		public void bill()
		{
			System.out.println("----bill-----");
			double total=0;
			for(Product p:buyinglist)
			{
				System.out.println(p.getProductname());
				total=total+p.getSellingprice();
				
				
			}
		System.out.println("total amount " + total);	
		}
		
		
		
		public void FilterByprice()
		{
			
			sess=sesfact.openSession();
			
			
			org.hibernate.query.Query ql=sess.createQuery("Select p from Product p order by p.Sellingprice ");
			
			List<Product> plist3=ql.getResultList();
			for(Product p:plist3)
			{
				System.out.println(p.getSellingprice());
				System.out.println(p.getProductname());
			}
			
			
			
			
			
			
		}
		
		public void FilterByCategory()
		{
			sess=sesfact.openSession();
			
			
			org.hibernate.query.Query ql=sess.createQuery("Select p from Product p order by p.category");
			
			
			List<Product> plist4=ql.getResultList();
			for(Product p:plist4)
			{
				
				System.out.println(p.getProductname());
				System.out.println(p.getCategory());
			}
			
		}
		
		
		
		
		
	}
	
	
	
	
	


