package com.hibernate.dao;

import org.hibernate.*;
import org.hibernate.cfg.Configuration;

import com.Entity.Item;

import java.util.*;

public class StoreItem {
	
	
	private Session sess;
	private SessionFactory sesfact;
	private Transaction tx;
	private Scanner sc;
	
	public StoreItem()
	{
		sesfact=new Configuration().configure("Hibernate.cfg.xml").buildSessionFactory();
		sc=new Scanner(System.in);
		
		
	}
	public void store()
	{
		sess=sesfact.openSession();
		tx=sess.beginTransaction();
		
		System.out.println("Enter no. of Items:");
		int noofitems=sc.nextInt();
		for(int i=0;i<noofitems;i++)
		{
			Item item=new Item();
			
			System.out.println("Enter item name:");
			item.setItemname(sc.next());
			System.out.println("Enter category:");
			item.setCategory(sc.next());
			System.out.println("Enter buying price:");
			item.setBuyingPrice(sc.nextDouble());
			
			
		sess.save(item);
		System.out.println("item added");
		
			
		}
		tx.commit();
		
		
	}

}
