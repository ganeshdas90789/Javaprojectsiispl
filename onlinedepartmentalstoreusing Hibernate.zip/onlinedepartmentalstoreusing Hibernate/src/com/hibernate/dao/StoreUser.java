package com.hibernate.dao;

import java.util.List;
import java.util.Scanner;

import org.hibernate.*;
import org.hibernate.cfg.Configuration;

import com.Entity.Product;
import com.Entity.User;
import com.hibernate.service.ProductService;

public class StoreUser {
	
	private Session sess;
	private SessionFactory sesfact;
	private Transaction tx;
	private  Scanner sc;
	private ProductService ps;

	
public StoreUser()
{
	sesfact=new Configuration().configure("Hibernate.cfg.xml").buildSessionFactory();
	sc=new Scanner(System.in);
	ps=new ProductService();
	

}

public void userStore()
{
	sess=sesfact.openSession();
	tx=sess.beginTransaction();
	
	System.out.println("Enter the no of user:");
	int noofuser=sc.nextInt();
	for(int i=0;i<noofuser;i++)
	{
		User u=new User();
		System.out.println("Enter user id:");
		u.setUserId(sc.next());
		System.out.println("Enter password:");
		u.setPassword(sc.next());
		System.out.println("Enter email:");
		u.setEmailid(sc.next());
		System.out.println("Enter type:");
		u.setUsertype(sc.next());
		
		
		sess.save(u);
		System.out.println("successfully registered");
		
	}
	tx.commit();
	
	

}
public void checkUser()
{
	sess=sesfact.openSession();
	
	
	System.out.println("Enter the user id:");
	String uid=sc.next();
	System.out.println("Enter the password:");
	String pwd=sc.next();
	org.hibernate.query.Query ql=sess.createQuery("select u from User u where u.userId=:id and u.password=:wd");
	 ql.setParameter("id", uid);
	 ql.setParameter("wd", pwd);
	 List<User> ulist=ql.getResultList();
	 if(!ulist.isEmpty())
	 {
		 for(User u:ulist)
		 {
			 String type=u.getUsertype();
			 if(type.equals("user"))
{
	        System.out.println("login successful");
	        
	        String choice="y";
			int ch=0;
			
			while(choice.equals("y"))
			{
				System.out.println("enter choice:");
				System.out.println("1. view products");
				System.out.println("2. filter  by price");
				System.out.println("3. filter by category");
				System.out.println("4. Buy product");
				System.out.println("5. exit");
				ch=sc.nextInt();
				
			switch(ch)
			{
			case 1:ps.display();
				
				break;
			case 2:ps.Filter();
				break;
			case 3:ps.filter1();
				break;
			case 4:ps.Buying();
				break;
			
			case 5:
				System.exit(0);
			}
			System.out.println("Do you want to continue(y/n):");
			choice=sc.next();
			
			
			
			
			
			
			}
				
	
	
	
	
	
	
	
}
			 else
			 {
				 System.out.println("invalid");
			 }
		 }
	 }
	 
}

public void checkAdmin()
{
	sess=sesfact.openSession();

	
	System.out.println("Enter the user id:");
	String uid=sc.next();
	System.out.println("Enter the password:");
	String pwd=sc.next();
	
	org.hibernate.query.Query ql=sess.createQuery("select u from User u where u.userId=:id and u.password=:wd");
    ql.setParameter("id", uid);
    ql.setParameter("wd", pwd);
    List<User> ulist=ql.getResultList();
    if(!ulist.isEmpty())
    {
   
    	for(User u:ulist)
    	{
    		String type=u.getUsertype();
    		if(type.equals("admin"))
    		{
    	System.out.println(u.getUsertype());
    	System.out.println("login successful");
    	
    	String ch="y";
    	int choice=0;
    	while(ch.equals("y"))
    	{
    		System.out.println("Enter choice:");
    		System.out.println("1. insert product");
    		System.out.println("2.view products");
			System.out.println("3.Calculate selling Price.");
			System.out.println("4.view products by productid.");
			System.out.println("5.view products by category.");
			System.out.println("6.search product by name.");
			System.out.println("7.total amount spent");
			System.out.println("8.display profit.");
			System.out.println("9..exit");
			choice=sc.nextInt();
			
			
			switch(choice)
			{
			case 1:
				ps.insertProduct(u);
				break;
			case 2:ps.display();
				break;
			case 3:ps.Calculate();
				break;
			case 4:ps.View();
				break;
			case 5:ps.view1();
				break;
			case 6:ps.Search();
				break;
			case 7:ps.total();
				break;
			case 8:ps.profit();
				break;
			case 9:
				System.exit(0);
				
			  
			}
			System.out.println("Do you want to continue(y/n):");
			ch=sc.next();
    		
    	}
    	
    	
    	
    
    }
    
	
    	}
}
}
}




