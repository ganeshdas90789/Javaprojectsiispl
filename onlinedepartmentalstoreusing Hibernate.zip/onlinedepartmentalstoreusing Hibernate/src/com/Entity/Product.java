package com.Entity;

public class Product extends Item  {
	
	
	public int getProductid() {
		return productid;
	}
	public void setProductid(int productid) {
		this.productid = productid;
	}
	private int productid;
	private String productname;
	private String Category;
	private int quantity;
	private double Sellingprice;
	
	public String getProductname() {
		return productname;
	}
	public void setProductname(String productname) {
		this.productname = productname;
	}
	public String getCategory() {
		return Category;
	}
	public void setCategory(String category) {
		Category = category;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public double getSellingprice() {
		return Sellingprice;
	}
	public void setSellingprice(double sellingprice) {
		this.Sellingprice =getBuyingPrice()+ getBuyingPrice()*0.5;
	}
	private User uobj;
	public User getUobj() {
		return uobj;
	}
	public void setUobj(User uobj) {
		this.uobj = uobj;
	}

}
