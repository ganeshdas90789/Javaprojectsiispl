package com.Entity;

import java.util.Set;

public class User {
	
	private String userId;
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	private String emailid;
	private String password;
	private int  supercoins;
	private  String usertype;
	public String getUsertype() {
		return usertype;
	}
	public void setUsertype(String usertype) {
		this.usertype = usertype;
	}
	public int getSupercoins() {
		return supercoins;
	}
	public void setSupercoins(int supercoins) {
		this.supercoins = 100;
	}
	
	public String getEmailid() {
		return emailid;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	private  Set<Product> productset;
	public Set<Product> getProductset() {
		return productset;
	}
	public void setProductset(Set<Product> productset) {
		this.productset = productset;
	}

}
