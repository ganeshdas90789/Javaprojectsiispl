package com.training.java;

public class student {
	
		private int studentid;
		private String studentname;
		private double score;
		
		public void setStudentid(int studentid)
		{
			this.studentid=studentid;		
		}
		public  int getStudentid()
		{
			return studentid;
		}
		
	     public void setStudentname(String studentname)
	     {
	    	 this.studentname=studentname;
	     }
	     public String  getStudentname()
	     {
	    	 return studentname;
	     }
	     
	     public void setScore(int score)
	     {
	    	 this.score=score;
	    	 
	     }
	     public double getScore()
	     {
	    	 return score;
	     }
	}



