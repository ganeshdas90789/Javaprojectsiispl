package com.day2.java;

public class Analyze {
  
    int a[]=new int[] {10,12,20,30,25,40,32,31,35,50,60};

public void  Analyze1()
{
  for(int i=3;i<=8;i++)
   {
System.out.println(a[i]);
   }
     
}

public static void main(String args[])
{
Analyze a1=new Analyze();
a1.Analyze1();
}
}


