package com.bank.service;

import com.bank.dao.BankDAO;

public class DepositorService {
	
	private BankDAO bankdao;
	
	public DepositorService()
	{
		bankdao=new BankDAO();
	}
	public void insertbankdetails()
	{
		bankdao.insert();
	}
	public void showdetails()
	{
		bankdao.display();
	}
	public void updatedetails()
	{
		bankdao.deposite();
	}
	public void updatedetails2()
	{
		bankdao.withdraw();
	}
	public void updatedetails3()
	{
		bankdao.changeaddress();
	}
	public void updatedetails4()
	{
		bankdao.transactions();
	}
	

}
