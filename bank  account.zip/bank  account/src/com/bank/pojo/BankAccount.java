package com.bank.pojo;

public class BankAccount {
	 private int Accountno;
	private String depositorName;
	 private String AddressofDepositor;
	 private String TypeOfAccount;
	 private  double Balance;
	 private int noofTransaction=0;
	public String getDepositorName() {
		return depositorName;
	}
	public void setDepositorName(String depositorName) {
		this.depositorName = depositorName;
	}
	public String getAddressofDepositor() {
		return AddressofDepositor;
	}
	public void setAddressofDepositor(String addressofDepositor) {
		AddressofDepositor = addressofDepositor;
	}
	public String getTypeOfAccount() {
		return TypeOfAccount;
	}
	public void setTypeOfAccount(String typeOfAccount) {
		TypeOfAccount = typeOfAccount;
	}
	public double getBalance() {
		return Balance;
	}
	public void setBalance(double balance) {
		Balance = balance;
	}
	public int getNoofTransaction() {
		return noofTransaction;
	}
	public void setNoofTransaction(int noofTransaction) {
		this.noofTransaction = noofTransaction;
	}
	public int getAccountno() {
		return Accountno;
	}
	public void setAccountno(int accountno) {
		Accountno = accountno;
	}

}
