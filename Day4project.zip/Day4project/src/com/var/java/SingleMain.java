package com.var.java;

public class SingleMain {

	public static void main(String args[])
	{
		for(int x=1;x<=1000;x++)
		{
			Singleton s1=Singleton.getobj();
			s1.display();
		}
	}
}
