package com.var.java;

import java.util.Scanner;

public class Employee1 {
	private int empid;
	private String empname;
	protected Scanner Sc;
	
	public Employee1()
	{
		Sc=new Scanner(System.in);
	}
	
	public void accept()
	{
		System.out.println("Enter the empid:");
		empid=Sc.nextInt();
		System.out.println("Enter the empname:");
		empname=Sc.next();
	}
	
	
	

}
