package com.var.java;

public class Base{
	
	public void show()
	{
		System.out.println("This is parent class");
	}
	
	
	
	
        
	
}
