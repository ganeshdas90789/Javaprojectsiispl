package com.var.java;

public class Trainee extends Employee {
	
	public Trainee (long id, String Name, String address, long phone,double salary)
	{
		super(id, Name, address, phone,salary);
		super.employeeId=id;
		super.employeeName=Name;
		super.employeeAddress=address;
		super.employeePhone=phone;
		super.basicSalary=salary;
	
	
	
	}

	 /* public void calculateSalary()
	  {
		  double salary=basicSalary+(basicSalary*specialAllowance/100)+(basicSalary*Hra/100);
		  System.out.println(salary);
	  }*/
	
	
	

}
