package com.var.java;

public class Main {
	public static void main(String args[])
	{
		Derived d1=new Derived();
		
		Base b1=new Base();
		
		//calling method of parent class by b1
		
		b1.show();//it call parent method
		
		//method of child class by d1.
		
		d1.display(); //it calls child method
		
		
		//method of parent class by d1.
		
		d1.show();// it calls parent method.
	}

}
