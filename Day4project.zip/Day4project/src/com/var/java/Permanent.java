package com.var.java;

public class Permanent extends Employee1 {
	private String dateofjoining;
	private double Salary;
	
	public void accept()
	{
		System.out.println("Enter the dateofjoining:");
		dateofjoining=Sc.next();
		System.out.println("Enter the salary:");
		Salary=Sc.nextDouble();
	}
	public void display()
	{
		System.out.println("date of joining:" + "" + dateofjoining);
		System.out.println("Salary is: " + "" + Salary);
	}
	public static void main(String args[])
	{
		Employee1 e1=new Employee1();
		e1.accept();
		Permanent p1=new Permanent();
		p1.accept();
		p1.display();
	}

}
