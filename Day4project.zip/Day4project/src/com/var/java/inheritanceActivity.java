package com.var.java;

public class inheritanceActivity {

	public static void main(String[] args) {
		
	
		/*Manager m1=new Manager(126534,"peter","Chennai India",237844,65000);
		m1.calculateSalary();
		m1.calculatetransportAllowance();*/
		
		
		Menu m1=new Menu();
		m1.displaymenu();

	
		
		

		
		
		

	}

}
