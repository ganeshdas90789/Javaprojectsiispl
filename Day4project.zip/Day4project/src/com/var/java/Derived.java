package com.var.java;

public class Derived extends Base{
	
	public void display()
	{
		System.out.println("This is child");
	}

}
