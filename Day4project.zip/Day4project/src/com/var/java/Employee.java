package com.var.java;

public class Employee {
	
	protected long  employeeId;
	protected String employeeName;
	protected String employeeAddress;
	protected long employeePhone;
	protected double basicSalary;
    protected  double specialAllowance=250.80;
    protected  double Hra=1000.50;

    public Employee()
    {
    	
    }
    Employee emp1;
    
  public Employee(long id,String Name,String address,long phone,double salary)
  {
	  this.employeeId=id;
	  this.employeeName=Name;
	  this.employeeAddress=address;
	  this.employeePhone=phone;
	  this.basicSalary=salary;
  }
  
  
  
  public void calculateSalary()
  {
	  double salary=basicSalary+(basicSalary*specialAllowance/100)+(basicSalary*Hra/100);
	  System.out.println("salary is" + salary);
  }
  public void calculatetransportAllowance()
	{
		double allowance=0.1*basicSalary;
		System.out.println("allowance is" + allowance);
	}
  
 
  public void show()
  {
	  System.out.println("name is" +this.employeeName);
	  System.out.println("Address is" +this.employeeAddress);
	 // System.out.println("empsalary is" + calculateSalary());
	  
	  
  }
  
  

	
	

}
