package com.var.java;

public class Singleton {
	private static Singleton s1;
	private Singleton()
	{
		
	}
	public static Singleton getobj()
	{
		s1=new Singleton();
		return s1;
		
	}
	public void display()
	{
		System.out.println("singleton class");
	}

}
