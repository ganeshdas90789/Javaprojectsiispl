package com.var.java;

import java.util.Scanner;

public class Menu  {
	Scanner sc;
	Manager mn;
	Trainee t1;
	
	public Menu()
	{
		
	}
	
	public void displaymenu()
	{
		sc=new Scanner(System.in);
		String choice="y";
		int ch=0;
		
		while(choice.equals("y"))
		{
			
			System.out.println("Enter your choice:");
			System.out.println("1. show Manager details:");
			System.out.println("2. show trainee details.");
			System.out.println("3. exit ");
		
		ch=sc.nextInt();
		
		
		switch(ch)
		{
		case 1:
			System.out.print("Manager ");
			 mn=new Manager(126534,"peter","Chennai India",237844,65000);
			 mn.show();
			mn.calculateSalary();
			
			mn.calculatetransportAllowance();
			
			break;
		case 2:
			System.out.print("Trainee ");
			Trainee t1=new Trainee(29846,"jack","Mumbai Indian",442085,45000);
			t1.show();
			t1.calculateSalary();
			t1.calculatetransportAllowance();
			break;
		case 3:
			break;
		case 4:
			System.exit(0);
		}
		
		

		System.out.println("Do you want to continue(Y/N):");
		
		choice=sc.next();
		
		
		
		}
		
		
	}
	
	
	
	
	
	
	
	
	

}
