package com.var.java;

public class Code {
	
	private static int  studentid;
	private  static String studentname;
	
	public void display()
	{
		System.out.println(studentid);
		System.out.println(studentname);
	}
	
	public static void main(String args[])
	{
		Code c1=new Code();
		c1.studentid=101;
		//c1.studentname="Ganesha";
		c1.display();
	}

}
