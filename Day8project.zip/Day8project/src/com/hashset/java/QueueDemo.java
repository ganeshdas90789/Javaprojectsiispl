package com.hashset.java;

import java.util.LinkedList;
import java.util.Queue;

public class QueueDemo {
	
	public static void main(String args[])
	
	{
		Queue<String> queueDemo=new LinkedList<>();
		queueDemo.add("java");
		queueDemo.add("Welcome");
		queueDemo.add("java");
		queueDemo.add("Spring");
		
		System.out.println("first value:" + queueDemo.element());
		System.out.println(queueDemo.remove());
		//System.out.println(queueDemo.element());
				System.out.println(queueDemo.poll());
				System.out.println(queueDemo.element());
				System.out.println(queueDemo.peek());
		
		
	}

}
