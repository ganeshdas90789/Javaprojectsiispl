package com.hashset.java;

public class Complaint {
	
	private int complaintno;
	private String complaintMessage;
	public int getComplaintno() {
		return complaintno;
	}
	public void setComplaintno(int complaintno) {
		this.complaintno = complaintno;
	}
	public String getComplaintMessage() {
		return complaintMessage;
	}
	public void setComplaintMessage(String complaintMessage) {
		this.complaintMessage = complaintMessage;
	}

}
