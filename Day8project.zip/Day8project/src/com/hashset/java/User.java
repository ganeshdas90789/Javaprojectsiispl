package com.hashset.java;

import java.util.Objects;

public class User {
	
	private int userid;
	private String username;
	private String password;
	private String usertype;
	public String getUsertype() {
		return usertype;
	}
	public void setUsertype(String usertype) {
		this.usertype = usertype;
	}
	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	@Override
	public int hashCode() {
		return Objects.hash(password, userid, username, usertype);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		User other = (User) obj;
		return Objects.equals(password, other.password) && userid == other.userid && username == other.username
				&& Objects.equals(usertype, other.usertype);
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	

}
