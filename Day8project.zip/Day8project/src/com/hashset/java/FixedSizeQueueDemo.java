package com.hashset.java;

import java.util.concurrent.ArrayBlockingQueue;

public class FixedSizeQueueDemo {
	
	ArrayBlockingQueue<Integer> arrqueue;
	
	public FixedSizeQueueDemo()
	{
		arrqueue =new ArrayBlockingQueue<>(5);
		
	}
	
	public void insert()
	{
		arrqueue.add(10);
		arrqueue.add(40);
		arrqueue.add(50);
		arrqueue.offer(10);
		arrqueue.add(80);
		//arrqueue.offer(45);
		
		
		
	}
	
	public void display()
	{
		while(!arrqueue.isEmpty())
		{
			System.out.println("arraqueue"+ arrqueue.remove());
		}
	}
	
	public static void main(String args[])
	{
		FixedSizeQueueDemo fixed=new FixedSizeQueueDemo();
		fixed.insert();
		fixed.display();
	}

}
