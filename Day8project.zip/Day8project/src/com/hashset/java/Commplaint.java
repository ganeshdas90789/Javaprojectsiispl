package com.hashset.java;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class Commplaint {
	
	private Queue<Complaint> Complaintqueue;
	private Scanner sc;
	public Commplaint()
	{
		sc=new Scanner(System.in);
		Complaintqueue=new LinkedList<>();
		
		
	}
	
	public void insertComplaint()
	{
		System.out.println("How many Complaints u want:");
		int noofcomplaints=sc.nextInt();
		for(int x=1;x<=noofcomplaints;x++)
		{
			Complaint c1=new Complaint();
			System.out.println("Enter compalint no.");
			c1.setComplaintno(sc.nextInt());
			System.out.println("Enter complaint");
			c1.setComplaintMessage(sc.next());
			
			Complaintqueue.add(c1);
			
			
		
		}
	}
	
	
	public void handleCommplaint()
	{
		
		while(!Complaintqueue.isEmpty())
		{
			Complaint c=Complaintqueue.poll();
			System.out.println("complaint id  which is remoed is " + c.getComplaintno());
			System.out.println("complaint message which is removed" + c.getComplaintMessage());
			
		
		
		}
		
	}
	public static void main(String args[])
	{
		Commplaint c1=new Commplaint();
		c1.insertComplaint();
		c1.handleCommplaint();
	}
	

}
