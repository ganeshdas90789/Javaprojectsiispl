package com.hashset.java;

import java.util.HashSet;
import java.util.Locale.Category;
import java.util.Scanner;
import java.util.Set;

public class ProductMain {
	
	private Set<Product> pset;
	private Scanner sc;
	//private Set<Category> cat;
	
	public ProductMain()
	{
		sc=new Scanner(System.in);
		pset=new HashSet<>();
		
	}
	
	public void accept()
	{
		
		System.out.println("Enter no. of products:");
		int noofproducts=sc.nextInt();
		
		for(int i=0;i<noofproducts;i++)
		{
			Product p=new Product();
			System.out.println("Enter product id:");
			p.setProductid(sc.nextInt());
			System.out.println("Enter product name:");
			
			
			
			p.setProductname(sc.next());
			System.out.println("Enter price:");
		    p.setPrice(sc.nextInt());
			System.out.println("Enter category name:");
			p.setCategory(sc.next());;
			
			
			
	   boolean result=pset.add(p);
	   if(!result)
	   {
		   System.out.println("product already exist");
	   }
	   
	   else
	   {
		   System.out.println("product added.");
	   }
		}
	}
	
	public void display()
	{
		System.out.println("Enter the category:");
		String cat=sc.next();
		double total=0;
		
			for(Product p:pset)
			{
				
				if(p.getCategory().equals(cat))
					
				System.out.println(p.getProductname() );
				System.out.println(total=total+p.getPrice());
			}
		
	}
	
	public void saleprice()
	{
		System.out.println("----Sales price of all the products---");
		
		for(Product p:pset)
		{
			p.setPrice(p.getPrice()+p.getPrice()*0.2);
			System.out.println(p.getProductname()+ "-"+ p.getPrice());
		}
		
	}
	
	
	
	public static void main(String args[])
	{
		ProductMain m1=new ProductMain();
		m1.accept();
		m1.display();
		m1.saleprice();
		
				
	}

	
}
