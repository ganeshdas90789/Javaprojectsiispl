package com.hashset.java;

import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class SetDemo {
	
	private Set<String> setd;
	private Scanner sc;
	
	
	private SetDemo()
	{
		sc=new Scanner(System.in);
		setd=new HashSet<String>();
	}
	
	public void accept()
	{
		System.out.println("Enter how many strings u want to have:");
		int noofstring=sc.nextInt();
		for(int i=0;i<noofstring;i++)
		{
			System.out.println("Enter any string:");
			setd.add(sc.next())		;	
		}
		
		
	}
	public void display()
	{
		for(String s:setd)
		{
			System.out.println(s);
			
		}
	}
	public static void main(String args[])
	{
		
		SetDemo set=new SetDemo();
		set.accept();
		set.display();
		
	}
	
	

}
