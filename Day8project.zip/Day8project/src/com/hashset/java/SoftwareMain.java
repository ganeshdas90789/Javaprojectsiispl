package com.hashset.java;

import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class SoftwareMain {
	
	private Set<User> user1;
	
	private Scanner sc;
	
	
	public SoftwareMain()
	{
		sc=new Scanner(System.in);
		user1=new HashSet<>();
	}
	
	
	private void accept()
	{
		System.out.println("Enter no. of user :");
		int noofuser=sc.nextInt();
		for(int x=0;x<noofuser;x++)
		{
		User u1=new User();
		System.out.println("Enter the userid:");
		u1.setUserid(sc.nextInt());
		System.out.println("Enter the username:");
		u1.setUsername(sc.next());
		System.out.println("Enter the password:");
		u1.setPassword(sc.next());
		System.out.println("Enter the usertype:");
		u1.setUsertype(sc.next());
		
		user1.add(u1);
		
		
		
		
		}
		
	}
	
	private void checkUser()
	{
		System.out.println("Enter the user name:");
		String name=sc.next();
		System.out.println("Enter the password:");
		String pwd=sc.next();
		boolean valid=false;
		for(User u:user1)
		{
			if(u.getUsername().equals(name) && u.getPassword().equals(pwd))
			{
				System.out.println("valid");
				break;
			}
			else
			{
				System.out.println("invalid");
				break;
			}
		}
		
		
	}
	
	public void navigate()
	{
		System.out.println("Enter the type:");
		String type=sc.next();
		for(User u:user1)
		{
			if(u.getUsertype().equals("admin"))
			{
				System.out.println("this  is admin page");
				break;
			}
			else
			{
				System.out.println("this is user page.");
				break;
			}
		}
	}
	public static void main(String args[])
	{
		SoftwareMain m1=new SoftwareMain();
		m1.accept();
		m1.checkUser();
		m1.navigate();
	}
	
	
	
	

}
