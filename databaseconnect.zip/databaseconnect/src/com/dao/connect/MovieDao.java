package com.dao.connect;

import java.util.ArrayList;
import java.util.List;

import com.connection.connect.DataConnect;
import com.dto.connect.Movie;
import java.sql.*;
import com.service.connect.MovieService;

public class MovieDao {
	
	private Connection con;
	private PreparedStatement stmt;
	private List<Movie> Mlist;

	
	public MovieDao()
	{
		con= DataConnect.getConnect();
		Mlist=new ArrayList<Movie>();
	
		
	}
	
	public  void insertData(List<Movie> moviedata) throws SQLException
	{
		
		
		
		
		con.setAutoCommit(false);
		stmt=con.prepareStatement("insert into Movie values(?,?,?,?)");
		for(Movie m:moviedata)
		{
			stmt.setInt(1, m.getMoviecode());
			stmt.setString(2,m.getMoviename() );
			stmt.setDouble(3, m.getPrice());
			stmt.setInt(4, m.getDuration());
			stmt.addBatch();
		}
		int result[]=stmt.executeBatch();
		if(result[0]>0)
		{
			System.out.println("inserted");
		}
		con.setAutoCommit(true);
		
		/*stmt=con.prepareStatement("insert into Movie values(?,?,?,?)");
		stmt.setInt(1, mv.getMoviecode());
		stmt.setString(2, mv.getMoviename());
		stmt.setDouble(3, mv.getPrice());
		stmt.setInt(4, mv.getDuration());
		int result=stmt.executeUpdate();
		
		if(result>0)
		{
			System.out.println("data inserted");
			
		}*/
	}
	
	public  List<Movie>  getDetails() throws SQLException
	{
		stmt= con.prepareStatement("select * from Movie");
		ResultSet rs= stmt.executeQuery();
		
		while(rs.next())
		{
			Movie m=new Movie();
			m.setMoviecode(rs.getInt(1));
			m.setMovietitle(rs.getString(2));
			m.setPrice(rs.getDouble(3));
			m.setDuration(rs.getInt(4));
			Mlist.add(m);
			
		}
		return Mlist;
	}
	

	public void deleteData(int mcode) throws SQLException {
	
		stmt=con.prepareStatement("delete from Movie where Movie_code=?");
		stmt.setInt(1, mcode);
		int result=stmt.executeUpdate();
		if(result>0)
		{
			System.out.println("deleted");
		}
		else
		{
			System.out.println("not deleted");
		}
		
		
	}
	public void updateData(int mcode) throws SQLException
	{
		stmt=con.prepareStatement("update Movie set price=667 where Movie_code=?");
		stmt.setInt(1, mcode);
		int result=stmt.executeUpdate();
		if(result>0)
		{
			System.out.println("update successful");
		}
		else
		{
			System.out.println("not update");
		}
		
	}
	public void total() throws SQLException
	{
		stmt=con.prepareStatement("select sum(price) as 'total money' from Movie");
		ResultSet rs=stmt.executeQuery();
		
		if(rs.next())
		{
			System.out.println("total price"+ rs.getDouble(1));
		}
		
	}
	public void movieDetails() throws SQLException ,MovieNotFoundException
	{
		try {
		stmt=con.prepareStatement("select movie_name from Movie where price>500");
		ResultSet rs=stmt.executeQuery();
		
		while(rs.next())
		{
			if(true)
			{
			System.out.println("movie name" + rs.getString(1));
			}
			
				
			
		}
		}
		catch(Exception e)
		{
			throw new MovieNotFoundException();
		}
		
	}
		


	public void  viewMovies(String mname) throws SQLException
	{
		stmt=con.prepareStatement("select * from Movie where movie_name=?");
		stmt.setString(1, mname);
		 ResultSet rs=stmt.executeQuery();
		 
		 if(rs.next())
		 {
			 System.out.println("movie code" + rs.getInt(1));
			 System.out.println("movie name" + rs.getString(2));
			 System.out.println("movie price" + rs.getDouble(3));
			 System.out.println("movie duration" + rs.getInt(4));
			 
		 
		 }
		 else
		 {
			 System.out.println("movie not found");
		 }
		
		
		
	}

}
