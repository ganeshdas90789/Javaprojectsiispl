package com.dao.connect;

public class MovieNotFoundException extends Exception {
	public String display()
	{
		return "movie not found";
	}

}
