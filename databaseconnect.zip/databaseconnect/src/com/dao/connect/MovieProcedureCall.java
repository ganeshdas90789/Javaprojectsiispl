package com.dao.connect;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Scanner;

import com.connection.connect.DataConnect;

public class MovieProcedureCall {
	
	private Connection con;
	private CallableStatement stmt;
	private Scanner sc;
	
	public MovieProcedureCall()
	{
		con=DataConnect.getConnect();
		sc=new Scanner(System.in);
	}
	public void callingProcedure() throws SQLException
	{
		System.out.println("Enter movie id:");
		int movieid=sc.nextInt();
		
		stmt=con.prepareCall("{call getMovie2(?,?)}");
		stmt.setInt(1, movieid);
		stmt.registerOutParameter(2, Types.VARCHAR);
	    stmt.executeUpdate();
		String moviename=stmt.getString(2);
		System.out.println("movie name is" + moviename);
		
	
	
	
	}
	public static void main(String args[])
	{
		MovieProcedureCall mv=new MovieProcedureCall();
		try {
			mv.callingProcedure();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
