package com.dto.connect;

public class Movie {
	
   private int Moviecode;
   private String moviename;
   private double price;
   private int duration;
public int getMoviecode() {
	return Moviecode;
}
public void setMoviecode(int moviecode) {
	Moviecode = moviecode;
}
public String getMoviename() {
	return moviename;
}
public void setMovietitle(String moviename) {
	this.moviename = moviename;
}
public double getPrice() {
	return price;
}
public void setPrice(double price) {
	this.price = price;
}
public int getDuration() {
	return duration;
}
public void setDuration(int duration) {
	this.duration = duration;
}
   
}
