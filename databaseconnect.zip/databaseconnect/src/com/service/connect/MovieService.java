package com.service.connect;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.dao.connect.MovieDao;
import com.dto.connect.Movie;

public class MovieService {
	private MovieDao md;
	private Scanner sc;
	private List<Movie>moviedata;
	
	
	
	public MovieService()
	{
		md=new MovieDao();
		sc=new Scanner(System.in);
		moviedata=new ArrayList<Movie>();
		
	}
	
	public void insertData()throws SQLException
	{
       System.out.println("Enter no of movies:");
       int noofmovies=sc.nextInt();
       for(int i=0;i<noofmovies;i++)
       {
		
			Movie mv=new Movie();
			System.out.println("Enter movie code:");
			mv.setMoviecode(sc.nextInt());
			System.out.println("Enter movie title:");
			mv.setMovietitle(sc.next());
			System.out.println("Enter price:");
			mv.setPrice(sc.nextDouble());
			System.out.println("Enter duration:");
			mv.setDuration(sc.nextInt());
			moviedata.add(mv);
       }
       md.insertData(moviedata);
	}
	
	public void retrieveData() throws SQLException
	{
		List<Movie> movieretrieve=md.getDetails();
		
		for(Movie m:movieretrieve)
		{
			System.out.println("movie title is:" + m.getMoviename());
			System.out.println("movie price is:"+ m.getPrice());
		}
		
	}
	public void deleteData() throws SQLException
	{
		System.out.println("Enter movie code:");
		int mcode=sc.nextInt();
		
	
		md.deleteData(mcode);
		
		
		
		
		
	}
	public void updateData() throws SQLException
	{
		System.out.println("enter movie code:");
		int mcode=sc.nextInt();
		md.updateData(mcode);
	}
	
	public void total() throws SQLException
	{
		md.total();
	}
	public void movieDetails() throws Exception
	{
		md.movieDetails();
	}
	public void viewMovies() throws SQLException
	{
		System.out.println("Enter movie name:");
		String mname=sc.next();
		md.viewMovies(mname);
	}
	

}
