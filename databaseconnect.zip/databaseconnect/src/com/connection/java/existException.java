package com.connection.java;

public class existException extends Exception {
	
	public String show()
	{
		return "alreayexist";
		
	}

}
