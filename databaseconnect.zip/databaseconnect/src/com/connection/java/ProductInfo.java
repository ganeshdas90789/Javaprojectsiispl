package com.connection.java;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import com.connection.connect.DataConnect;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.Statement;

public class ProductInfo {
	
	private Connection con;
	private PreparedStatement stmt;
	
	private Scanner Sc;
	
	
	public ProductInfo()
	{
		con=(Connection) DataConnect.getConnect();
		Sc=new Scanner(System.in);
	}
	
	public void insertData() throws SQLException
	{
		System.out.println("Enter how many prducts u want to add:");
		int noofproducts=Sc.nextInt();
		stmt=(PreparedStatement) con.prepareStatement("insert into ProductDetails(productname,quantity,category) values(?,?,?)");
		for(int i=0;i<noofproducts;i++)
		{
			//System.out.println("Enter product id:");
			//stmt.setInt(1, Sc.nextInt());
			System.out.println("Enter product name:");
			stmt.setString(1, Sc.next());
			//System.out.println("Enter price: ");
			//stmt.setDouble(3, Sc.nextDouble());
			System.out.println("Enter quantity:");
			stmt.setInt(2, Sc.nextInt());
			System.out.println("Enter category:");
			stmt.setString(3, Sc.next());
			int result=stmt.executeUpdate();
			if(result>0)
			{
				System.out.println("inserted");
			}
			else
			{
				System.out.println("not inserted");
			}
			
		}
	}
	public void delete() throws SQLException
	{
		System.out.println("enter the product name :");
		String pname=Sc.next();
		stmt=(PreparedStatement) con.prepareStatement("delete from ProductDetails where productname=?");
		stmt.setString(1, pname);
		int result=stmt.executeUpdate();
		if(result>0)
		{
			System.out.println("deleted");
		}
		
	
	}
	
		
	
	public static void main(String [] args) throws SQLException
	{
		ProductInfo prinfo=new ProductInfo();
		//prinfo.insertData();
		prinfo.delete();
		
	}

}
