package com.connection.java;

import java.sql.SQLException;
import java.util.Scanner;

import com.connection.connect.DataConnect;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;

public class User {
	
	public Connection con;
	
	public Statement stmt;
	private Scanner Sc;
	
	public User()
	{
		con=(Connection) DataConnect.getConnect();
	}
	
	public void  create()
	{
		try {
		stmt=(Statement) con.createStatement();
		int result=stmt.executeUpdate("create table UserDetails(user_id int,user_name varchar(20),password int)");
		if(result>0)
		{
			System.out.println("table created ");
		}
		}
		catch(SQLException ex)
		{
			System.out.println(ex.getMessage());
		}
		
	}
	
	public void insert()
	
		
	{
		try {
		stmt=(Statement) con.createStatement();
		int result=stmt.executeUpdate("insert into UserDetails values(1,'ganesha',123)");
		if(result>0)
		{
			System.out.println("inserted ");
		}
		}
		catch(SQLException ex)
		{
			System.out.println(ex.getMessage());
		}
	}
	public void checkUser(String user_name,int pass)
	
	{
		try {
		stmt=(Statement) con.createStatement();
		
ResultSet result=(ResultSet) stmt.executeQuery("select * from UserDetails where user_name='"+user_name+"' and password="+pass+"");


		
	
			if(result.next())
			{
			System.out.println("userid is:" + " " + result.getInt(1));
			System.out.println("usename is:" + " " + result.getString(2));
			System.out.println("password is:"+ "  " + result.getInt(3));
				System.out.println("valid");
		}
			else
			{
				System.out.println("invalid");
			}
		
		}catch(SQLException e)
		{
			System.out.println(e.getMessage());
		}
	}
	
	
	
	
	
	
	
	
	
	
	public static void main(String args[])
	{
		User u=new User();
		//u.create();
		//u.insert();
		u.checkUser("ganesha", 123);
		
	}

}
