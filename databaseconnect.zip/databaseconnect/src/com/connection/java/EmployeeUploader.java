package com.connection.java;

import java.sql.CallableStatement;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Scanner;
import java.util.Set;

import com.connection.connect.DataConnect;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.ResultSet;

public class EmployeeUploader {
	
	private Connection con;
	private PreparedStatement stmt;
	private CallableStatement stat;
	private Scanner Sc;

	
	
	public EmployeeUploader()
	{
		con=(Connection) DataConnect.getConnect();
		Sc=new Scanner(System.in);

	}
	public void storeDepartmentDetails() throws SQLException
	{
		System.out.println("Enter how many departments u want to add:");
		int noofdepartment=Sc.nextInt();
		stmt=(PreparedStatement) con.prepareStatement("insert into Department values(?,?,?,?)");
		
		for(int i=0;i<noofdepartment;i++)
		{
			System.out.println("enter department id:");
			stmt.setInt(1, Sc.nextInt());
			System.out.println("Enter department name:");
			stmt.setString(2, Sc.next());
			System.out.println("Enter department head:");
			stmt.setString(3, Sc.next());
			System.out.println("enter depart desc:");
			stmt.setString(4, Sc.next());
			
			int result=stmt.executeUpdate();
			if(result>0)
			{
				System.out.println( "data inserted");
			}
			else
			{
				System.out.println("not inserted");
			}
		}
		
	}
	
	public void storeEmployeeDetails() throws SQLException,existException
	{
		System.out.println("Enter how many Employees u want to add:");
		int noofemployee=Sc.nextInt();
		try {
		stmt=(PreparedStatement) con.prepareStatement("insert into employee values(?,?,?,?,?,?)");
		for(int i=0;i<noofemployee;i++)
		{
			
			System.out.println("Enter employee id:");
			stmt.setInt(1, Sc.nextInt());
			System.out.println("Enter employee name:");
			stmt.setString(2, Sc.next());
			System.out.println("Enter employee address:");
			stmt.setString(3, Sc.next());
			System.out.println("Employee salary:");
			stmt.setDouble(4, Sc.nextDouble());
			System.out.println("Enter contact no.:");
			stmt.setString(5, Sc.next());
			System.out.println("Enter department id:");
			stmt.setInt(6, Sc.nextInt());
			
			int result=stmt.executeUpdate();
			if(result>0)
			{
				System.out.println("data inserted");
			}
			else
			{
				System.out.println("data not inserted");
			}
			
		}
		}catch(Exception e)
		{
			throw new existException();
		}
		
	}
	
	public void retrieveEmployeeDetails() throws SQLException
	{
		
		System.out.println("Enter empid :");
		int eid=Sc.nextInt();
		stmt=(PreparedStatement) con.prepareStatement( "select *  from employee where employee_id="+eid+"");
		ResultSet rs=(ResultSet) stmt.executeQuery("select employee_id,employee_name,employee_contact_no,employee_address,department_name,department_head from employee e  join Department d on d.department_id=e.department_id ");
		if(rs.next())
		{
			System.out.println("emp id:" + rs.getInt(1));
			System.out.println("emp name is:" + rs.getString(2));
			System.out.println("emp contact no:" + rs.getString(3));
			System.out.println("emp address" + rs.getString(4));
			System.out.println("department name" + rs.getString(5));
			System.out.println("department head" + rs.getString(6));
		}
		else
		{
			System.out.println(" employee id not present.");
		}
	}
	
	public void calculatePF() throws SQLException
	{
		System.out.println("Enter employee id:");
		int employeeid=Sc.nextInt();
		
		stat=con.prepareCall("{call calculate3(?,?)}");
		stat.setInt(1, employeeid);
		stat.registerOutParameter(2, Types.INTEGER);
		stat.executeUpdate();
		int pfamount=stat.getInt(2);
		System.out.println("the pf amount is" + pfamount);
		
		
	}
	
	
	
	
	public static void main(String args[]) throws SQLException
	{
		EmployeeUploader eup=new EmployeeUploader();
		try {
			eup.storeEmployeeDetails();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (existException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//eup.storeDepartmentDetails();
		//eup.retrieveEmployeeDetails();
		//eup.calculatePF();
	}
	
	

}
