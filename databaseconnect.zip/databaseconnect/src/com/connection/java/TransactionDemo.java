package com.connection.java;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import com.connection.connect.DataConnect;

public class TransactionDemo {
	
	private Connection con;
	private PreparedStatement stmt;
	private Scanner sc;
	private TransactionDemo()
	{
		sc=new Scanner(System.in);
		con=DataConnect.getConnect();
		
	}
	public void insert() throws SQLException
	{
		System.out.println("Enter how many data u want to insert:");
		int noofdata=sc.nextInt();
		stmt=con.prepareStatement("insert into Account values(?,?,?)");
		for(int i=0;i<noofdata;i++)
		{
			System.out.println("Enter customer code:" );
			stmt.setInt(1, sc.nextInt());
			System.out.println("enter customer name:");
			stmt.setString(2, sc.next());
			System.out.println("enter balance:");
			stmt.setDouble(3,sc.nextDouble());
		}
		int result=stmt.executeUpdate();
		
		if(result>0)
		{
			System.out.println("data iserted");
		}
		
	
	}
	public void updateBalance() throws SQLException
	{
		con.setAutoCommit(true);
		double balance1=0;
		stmt=con.prepareStatement("select balance from Account where customercode=1001" );
		ResultSet result=stmt.executeQuery();
		if(result.next())
		{
			balance1=result.getDouble(1);
			//System.out.println(balance1);
			
		}
		
		System.out.println("Enter the amount which u want to withdraw:");
		double withdraw=sc.nextDouble();
		if(withdraw>balance1)
		{
			con.rollback();
		}
		else
		{
			stmt=con.prepareStatement("update Account set balance=balance-"+withdraw+" where customercode=1001");
			int result1=stmt.executeUpdate();
			if(result1>0)
			{
				System.out.println("first account updated");
			}
		      stmt=con.prepareStatement("update Account set balance=balance+40000 where customercode=1002");
		      int result2=stmt.executeUpdate();
		      if(result2>0)
		      {
		    	  System.out.println("second account also updated");
		      }
		      else
		      {
		    	  con.commit();
		      }
		}
	}
	public static void main(String args[]) throws SQLException
	{
		TransactionDemo tm=new TransactionDemo();
		//tm.insert();
		tm.updateBalance();
				
			
				
	}

}
