package com.connection.java;

import java.sql.SQLException;

import javax.sql.rowset.CachedRowSet;
import javax.sql.rowset.RowSetProvider;

public class CachedRow {
	
	CachedRowSet rowset;
	
	public CachedRow()
	{
		 try {
				Class.forName("com.mysql.jdbc.Driver");
				
		 rowset= RowSetProvider.newFactory().createCachedRowSet();
		 rowset.setUrl("jdbc:mysql://localhost:3306/ganesha?relaxAutoCommit=true");
		 rowset.setUsername("root");
		 rowset.setPassword("Ganesha@123");
				}catch(SQLException e)
				{
					
				}catch(ClassNotFoundException e)
				{
					
				}
		
	 }
	
	public void operation() throws SQLException
	{
		rowset.setCommand("select * from Movie");
		rowset.execute();
		rowset.next();
		
		rowset.moveToInsertRow();
		rowset.updateInt(1,5);
		rowset.updateString(2, "newsMovie");
		rowset.updateDouble(3, 3900);
		rowset.updateInt(4,5);
		rowset.insertRow();

		rowset.moveToCurrentRow();
		rowset.acceptChanges();
		
		System.out.println("inserted");
		
		
	}
	public static void main(String args[])
	{
		CachedRow rw=new CachedRow();
		try {
			rw.operation();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	}


