package com.connection.java;

import java.sql.SQLException;
import java.sql.DriverManager;
import javax.sql.rowset.JdbcRowSet;
import javax.sql.rowset.RowSetProvider;

public class Rowset {
	
 JdbcRowSet rowset;
 public Rowset() 
 {
	 try {
			Class.forName("com.mysql.jdbc.Driver");
			
	 rowset= RowSetProvider.newFactory().createJdbcRowSet();
	 rowset.setUrl("jdbc:mysql://localhost:3306/ganesha");
	 rowset.setUsername("root");
	 rowset.setPassword("Ganesha@123");
			}catch(SQLException e)
			{
				
			}catch(ClassNotFoundException e)
			{
				
			}
	
 }
 public void retrieveData() throws SQLException
 {
	 rowset.setCommand("select * from ProductDetails");
	 rowset.execute();
	 while(rowset.next())
	 {
		 System.out.println("product code is" + rowset.getInt(1));
	 }
 }
 
 public static void main(String args[]) throws SQLException
 {
	 Rowset rw=new Rowset();
	 rw.retrieveData();
 }

}
