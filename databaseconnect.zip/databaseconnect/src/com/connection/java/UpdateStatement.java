package com.connection.java;


import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.connection.connect.DataConnect;

public class UpdateStatement {
	
	public static void main(String args[]) throws SQLException
	{
		Connection con=DataConnect.getConnect();
		Statement stmt=con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);
		ResultSet result=stmt.executeQuery("select * from Department");
		
		result.next();
		result.updateInt(1, 1001);
		result.updateRow();
		System.out.println("1 row updated");
		con.close();
	}

}
