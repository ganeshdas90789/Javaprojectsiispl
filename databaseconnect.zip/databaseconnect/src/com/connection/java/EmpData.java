package com.connection.java;

import java.sql.Connection;
import java.sql.SQLException;
import com.connection.connect.DataConnect;
import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;

public class EmpData {
	
	private Connection con;
	public Statement stat;
	
	
	public  EmpData()
	{
		con=DataConnect.getConnect();
		
	}
	
	
	public void insertData()
	{
		try {
		
			
			stat=   (Statement) con.createStatement();
		 int result=stat.executeUpdate("insert into student values(4,'ganesha','python')");
		 
		 if(result>0)
		 {
			 System.out.println("data inserted successfully");
		 }
		 else
		 {
			 System.out.println("data not inserted");
		 }
		}
		catch(SQLException ex)
		{
			System.out.println(ex.getMessage());
		}
	}
	
	public void updateData(int student_id,String name )
	{
		try {
		stat=(Statement) con.createStatement();
		int result=stat.executeUpdate("update student set course_name ='"+name+"' where student_id="+student_id+"");
		
		if(result>0)
		{
			System.out.println("data updated successfully.");
		}
		else
		{
			System.out.println("not updated");
		}
		}catch(SQLException ex)
		{
			System.out.println(ex.getMessage());
		}
		
	}
	
	public void deleteData(int student_id)
	{
		try {
		stat=(Statement) con.createStatement();
		int result=stat.executeUpdate("delete from student where student_id="+student_id+"");
		if(result>0)
		{
			System.out.println("deleted");
		}
		else
		{
			System.out.println("not deleted");
		}
		}
		catch(SQLException ex)
		{
			System.out.println(ex.getMessage());
		}
	}
	
	public void retrieveData()
	{
		try {
		stat=(Statement) con.createStatement();
		ResultSet result=(ResultSet) stat.executeQuery("select * from student");
		
		while(result.next())
		{
			System.out.println("student_id is:" + " " + result.getInt(1));
			System.out.println("student_name is:" + " " + result.getString(2));
			System.out.println("course_name is:"+ "  " + result.getString(3));
		} 
		}
		catch(SQLException ex)
		{
			System.out.println(ex.getMessage());
		}
	}
	
	
	
	public static void main(String []args)
	{
		EmpData e1=new EmpData();
		//e1.insertData();
		//e1.updateData(3,"c language");
		//e1.deleteData(2);
		e1.retrieveData();
	}

}
