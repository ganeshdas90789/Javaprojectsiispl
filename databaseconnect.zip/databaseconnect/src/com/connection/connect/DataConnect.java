package com.connection.connect;

import java.sql.*;

public class DataConnect {
	 private static Connection con;
	 
	 private DataConnect()
	 {
		 try {
			Class.forName("com.mysql.jdbc.Driver");
			
			
			try {
				con=DriverManager.getConnection("jdbc:mysql://localhost:3306/ganesha","root","Ganesha@123");
				System.out.println("connection established");
				//Statement stmt=con.createStatement();
				//System.out.println(stmt.executeQuery("select * from Employee"));
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	 }
	 
	 public static Connection getConnect()
	 
	 {
		 
		 DataConnect c2=new DataConnect();
		return con ;
		 
	 }
	 public static void main(String []args)
	 {
	//DataConnect c3=new DataConnect();
		getConnect();
	 }
	
	

}
