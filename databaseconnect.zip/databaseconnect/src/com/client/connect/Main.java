package com.client.connect;

import com.menu.connect.MovieMenu;

public class Main {
	public static void main(String args[])
	{
		MovieMenu m1=new MovieMenu();
		m1.displayMenu();
	
		
	}

}
