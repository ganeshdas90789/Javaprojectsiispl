package com.menu.connect;

import java.sql.SQLException;
import java.util.Scanner;

import com.service.connect.MovieService;

public class MovieMenu {
	private Scanner sc;
	
	private MovieService ms;
	
	public MovieMenu()
	{
		ms=new MovieService();
		sc=new Scanner(System.in);
	}
	
	public void displayMenu()
	{
		int choice;
		String ch="y";
		
		
		
		while(ch.equals("y"))
		{
			System.out.println("1.Insert Movie");
			System.out.println("2.delete movie");
			System.out.println("3.update movie");
			System.out.println("4.view movie");
			System.out.println("5. total money spent");
			System.out.println("6.view movies");
			System.out.println("7.price greater than 500 movies");
			System.out.println("8. exit");
			
			choice=sc.nextInt();

			switch(choice)
			{
			
			case 1:try {
					ms.insertData();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			case 2:try {
					ms.deleteData();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				break;
			case 3:try {
					ms.updateData();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				break;
			case 4:try {
					ms.retrieveData();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			case 5:try {
					ms.total();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				break;
			case 6:try {
					ms.viewMovies();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			
				break;
			case 7:
				try {
					ms.movieDetails();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			case 8:
				System.exit(0);
				break;
			}
			
		}
		System.out.println("Do you want to continue(y/n)");
		ch=sc.next();
		
		
		
	}
	
	

}
