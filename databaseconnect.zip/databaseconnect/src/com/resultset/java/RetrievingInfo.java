package com.resultset.java;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

import com.connection.connect.DataConnect;

public class RetrievingInfo {
	
	private PreparedStatement stat;
	private Connection con;
	
	
	public RetrievingInfo()
	{
		con=DataConnect.getConnect();
	}
	public void retrieveData() throws SQLException
	{
		stat=con.prepareStatement("select * from Movie");
		ResultSet rs=stat.executeQuery();
		while(rs.next())
		{
			System.out.println("movie id is" + rs.getInt(1));
			System.out.println("movie name is" + rs.getString(2));
		}
		ResultSetMetaData result=rs.getMetaData();
		System.out.println("column name of 1st column is" + result.getColumnName(1));
		System.out.println("total column returned in result set:" + result.getColumnCount());
		System.out.println("data type of 2nd column" + result.getColumnTypeName(2));
		
	DatabaseMetaData dm=con.getMetaData();
	ResultSet get=dm.getCatalogs();
	while(get.next())
	{
		System.out.println(get.getString(1));
		
	}
	System.out.println(dm.getDriverName());
		
	}
	
	
	public void insertImage() throws SQLException, IOException
	{
		stat=con.prepareStatement("insert into employee1 values(?,?)");
		stat.setString(1, "firstImage");
		FileInputStream input=new FileInputStream("/home/administrator/Documents/images.jpeg");
		stat.setBinaryStream(2, input, input.available());
		int result=stat.executeUpdate();
		if(result>0)
		{
			System.out.println("data inserted");
		}
		else
		{
			System.out.println("data not inserted");
		}
		
	}
	public void readImage() throws SQLException, IOException
	{
		stat=con.prepareStatement("select emppic from employee1 where imagename=?"  );
		stat.setString(1, "firstimage");
		ResultSet rs=stat.executeQuery();
		
		if(rs.next())
		{
			Blob imgdata=rs.getBlob(1);
			byte arr[]=imgdata.getBytes(1, (int)imgdata.length());
			FileOutputStream output=new FileOutputStream("/home/administrator/Documents/images1.jpeg");
			output.write(arr);
			System.out.println("file read");
		}
	}

	
	public static void main(String args[])
	{
		RetrievingInfo ri=new RetrievingInfo();
		try {
			ri.retrieveData();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		/*try {
			ri.insertImage();
		} catch (SQLException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		/*try {
			ri.readImage();
		} catch (SQLException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		
	}

}
