package com.myshopee.com;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

import com.connection.connect.DataConnect;

public class MyshopUpload {
	
	private PreparedStatement stmt;
	private Connection con;
	private Scanner sc;
	
	public MyshopUpload()
	{
		con=DataConnect.getConnect();
		sc=new Scanner(System.in);
		
	}
	
	public void storeItemDetails() throws SQLException
	{
		System.out.println("Enter how many items u want to add:");
		int noofitems=sc.nextInt();
		
		stmt=con.prepareStatement("insert into item values(?,?,?,?)");
		
		for(int i=0;i<noofitems;i++)
		{
			
		}
		
	}
	
	
	
	
	
	
	
	
	
	public static void main(String args[])
	{
		
	}
	
	
	
	

}
