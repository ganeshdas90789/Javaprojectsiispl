package com.dao.project;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.pojo.project.Product;
import com.pojo.project.User;
import com.service.project.Service;

public class UserMain {
	
	private Scanner sc;
	
	ProductMain m1;
	
	
	private List<User> userlist;
	
	public UserMain()
	{
		sc=new Scanner(System.in);
		userlist=new ArrayList<User>();
		m1=new ProductMain();
		
		
		
	}
	
	
	public void accept()
	{
		System.out.println("Enter the number of users:");
		int noofuser=sc.nextInt();
		
		for(int i=0;i<noofuser;i++)
		{
			User u1=new User();
			System.out.println("Enter username:");
			u1.setUsername(sc.next());
			System.out.println("Enter password:");
			u1.setPassword(sc.next());
			System.out.println("Enter emailid:");
			u1.setEmailid(sc.next());
			userlist.add(u1);
			
		}
		System.out.println("Registered successfully ! 100 supercoins are added as welcome bonus");
	}
	
	public void checkUser()
	{
		System.out.println("Enter username:");
		String uname=sc.next();
		System.out.println("Enter password:");
		String pass=sc.next();
		userlist.stream().filter(match->match.getUsername().equals(uname) && match.getPassword().equals(pass)).forEach(s->
		
		{
			System.out.println("login Successful");
			
			
				String choice="y";
				int ch=0;
				
				while(choice.equals("y"))
				{
					System.out.println("enter choice:");
					System.out.println("1.view products");
					System.out.println("2.exit");
					ch=sc.nextInt();
					
					switch(ch)
					{
					case 1:
						m1.display();
						break;
						
					case 2:
						
						System.exit(0);
						
					}
					System.out.println("Do you want to continue(y/n):");
					choice=sc.next();
					
					
				}
				
			
			
			
			
			
		}
				
				
				);
	}
	public void checkAdmin()
	{
		System.out.println("Enter username:");
		String name=sc.next();
		System.out.println("Enter password:");
		String pwd=sc.next();
		
		if(name.equals("admin") && pwd.equals("password"))
		{
			
				String choice="y";
				int ch=0;
				
				
			while(choice.equals("y")) 
			
			
			{
				
				
				System.out.println("enter choice:");
				System.out.println("1.insert Products");
				System.out.println("2.view products");
				System.out.println("3.Calculate selling Price.");
				System.out.println("4.view products by productid.");
				System.out.println("5.view products by category.");
				System.out.println("6.search product by name.");
				System.out.println("7.total amount spent");
				System.out.println("8.display profit.");
				System.out.println("9..exit");
				ch=sc.nextInt();
				switch(ch)
				{
				case 1:
					m1.accept1();;
					break;
					
				case 2:
					m1.display();
					break;
					
				case 3:
					m1.calculate();
					break;
					
				case 4:
					m1.productByProductid();
					break;
				case 5:
					m1.productByCategory();
					break;
				case 6:
					m1.productByName();
					break;
				case 7:
					m1.total();
					break;
				case 8:
					m1.profit();
					break;
				case 9:
					System.exit(0);
					
				
				
				}
				System.out.println("Do you want to continue(y/n):");
				choice=sc.next();
				
				

		

	}
	
		}
	
	
	
	}

}
