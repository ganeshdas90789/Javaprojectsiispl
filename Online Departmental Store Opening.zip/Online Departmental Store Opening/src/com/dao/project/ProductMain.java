package com.dao.project;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import com.menu.project.Menu;
import com.pojo.project.*;
public class ProductMain  {
	

	Map<Integer,Product> product;
	List<Product> plist;
	
	private Scanner sc;
	
	public ProductMain()
	{
		sc=new Scanner(System.in);
		product=new HashMap<Integer,Product>();
		plist=new ArrayList<Product>();
	}
	
	public void accept1()
	{
		System.out.println("Enter number of product:");
		int noofproduct=sc.nextInt();
		
		for(int i=0;i<noofproduct;i++)
		{
			Product m1=new Product();
			System.out.println("Enter productid:");
		int code=	m1.setProductid(sc.nextInt());
			System.out.println("Enter productname:");
			m1.setProductName(sc.next());
			System.out.println("Enter buying price:");
			m1.setSellingPrice(sc.nextDouble());
			System.out.println("Enter availablequantity:");
			m1.setAvailableQuantity(sc.nextInt());
			System.out.println("Enter category:");
			m1.setCategory(sc.next());
			
			product.put(m1.getProductid(), m1);
			plist.add(m1);
		}
	}
	
	
	public void display()
	{
		product.entrySet().stream().forEach(s->
		
				
				{
					System.out.println(s.getValue().getProductName());
				}
				
				);
		
	}
	double sellingprice;
	
	public void calculate()
	{
		product.entrySet().stream().forEach(n->
		
				
		{
			 sellingprice=((n.getValue().getBuyingPrice()*0.5+n.getValue().getBuyingPrice()));
			 System.out.println("Sellingprice is" + sellingprice);
		}
				);
		
	}
	
	public void productByProductid()
	{
		System.out.println("Enter productid:");
		int pid=sc.nextInt();
		
	boolean ans=product.entrySet().stream().allMatch(n->n.getValue().getProductid()==pid);
	if(true)
	{
		product.entrySet().stream().forEach(s->
		
				{
					System.out.println(s.getValue().getProductName());
				});
	}
	else
	{
		System.out.println("not found");
	}
		
		
		
		
	}
	
	public void productByCategory()
	{
		System.out.println("Enter category:");
		String cat=sc.next();
		
		boolean ch=product.entrySet().stream().allMatch(n->n.getValue().getCategory().equals(cat));
		if(true)
		{
			product.entrySet().stream().forEach(s->
			
					{
					System.out.println(s.getValue().getProductName());	
					}
					);
		}
		else
		{
			System.out.println("not found");
		}
		
	}

	
	
	public void productByName()
	{
		System.out.println("Enter name:");
		String nm=sc.next();
		
		boolean ch=product.entrySet().stream().allMatch(n->n.getValue().getProductName().equals(nm));
		if(true)
		{
			product.entrySet().stream().forEach(s->
			
					{
					System.out.println(s.getValue().getProductName());	
					}
					);
		}
		else
		{
			System.out.println("not found");
		}
		
	}
	int total=0;
	public void total()
	{
		product.entrySet().stream().forEach(n->
		
				
		
		
		{
			
			total=(int) (total+n.getValue().getBuyingPrice());
		}
				);
		System.out.println(total);
	}
	double profit;
	public void profit()
	{
		System.out.println("Enter category");
		String cate=sc.next();
		
		
		boolean cat=product.entrySet().stream().allMatch(n->n.getValue().getCategory().equals(cate));
		if(true)
		{
			product.entrySet().stream().forEach(s->
			
					{
						
					   profit=sellingprice-s.getValue().getBuyingPrice();	
					   System.out.println(profit);
					}
					);
		}
		else
		{
			System.out.println("not found");
		}
		
		
		
		
		
		
		
		
		
		
		
	}
	
}
