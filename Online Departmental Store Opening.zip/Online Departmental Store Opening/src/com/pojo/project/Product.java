package com.pojo.project;

import java.util.Map;

public class Product extends Item {
	
	private int productid;
	private String productName;
	private double buyingPrice;
	private int availableQuantity;
	private String category;
    
	public Map<Integer,Product> product;
	
	
	public int getProductid() {
		return productid;
	}
	public Map<Integer,Product> getProduct() {
		return product;
	}
	public void setProduct(Map<Integer,Product> product) {
		this.product = product;
	}
	public int setProductid(int productid) {
		return this.productid = productid;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public double getBuyingPrice() {
		return buyingPrice;
	}
	public void setSellingPrice(double sellingPrice) {
		this.buyingPrice = sellingPrice;
	}
	public int getAvailableQuantity() {
		return availableQuantity;
	}
	public void setAvailableQuantity(int availableQuantity) {
		this.availableQuantity = availableQuantity;
	}
	

}
