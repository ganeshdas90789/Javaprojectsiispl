package com.service.project;

import com.dao.project.UserMain;
import com.dao.project.ProductMain;


public class Service
{
	UserMain umain;
	ProductMain pmain;
	public void view() {
		pmain.display();
	}
	public Service()
	{
		umain=new UserMain();
		
	}
	
	public void insertDetails()
	{
		umain.accept();
	}
	public void check()
	{
		umain.checkUser();
	}
	public void check1()
	{
		umain.checkAdmin();
	}
	public void show()
	{
		pmain.accept1();
	}
	public void show2()
	{
		pmain.display();
	}

}
