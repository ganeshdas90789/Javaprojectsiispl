package com.main.project;

import com.menu.project.Menu;

public class Main {
	
	public static void main(String args[])
	{
		Menu m1=new Menu();
		m1.displayMenu();
		
		
	}

}
