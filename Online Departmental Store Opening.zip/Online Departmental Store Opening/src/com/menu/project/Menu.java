package com.menu.project;

import java.util.Scanner;

import com.dao.project.ProductMain;
import com.service.project.*;
public class Menu  {
	

	private Scanner sc;
	Service s1;
	
	public Menu()
	{
		s1=new Service();
	}
	
	
	public void displayMenu()
	{
		sc=new Scanner(System.in);
		String choice ="y";
		int ch=0;
		
		while(choice.equals("y"))
		{
			System.out.println("Enter your choice:");
			System.out.println("1.Register:");
			System.out.println("2.login as user:");
			System.out.println("3. Login as admin:");
			System.out.println("4. Exit");
			
			ch=sc.nextInt();
			
			
			switch(ch)
			{
			
			case 1:
				s1.insertDetails();
				break;
				
			case 2:
				s1.check();
				break;
				
			case 3:
				s1.check1();
				break;
			case 4:
				System.exit(0);
				
				
			
			}
			
			System.out.println("Do you want to continue(y/n):");
			choice=sc.next();
		}
	}
		

				
			
		
	
	
}

