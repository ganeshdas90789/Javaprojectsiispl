package com.menu.java;

import java.sql.SQLException;
import java.util.Scanner;

import com.service.java.CustomerNotFoundException;
import com.service.java.CustomerService;
import com.service.java.IdNotFoundException;
import com.service.java.ItemService;
import com.service.java.PurchaseService;

public class Menu {
	
	private ItemService is;
	private CustomerService cs;
	private PurchaseService ps;
	private Scanner sc;
	
	public Menu()
	{
		is=new ItemService();
		cs=new CustomerService();
		ps=new PurchaseService();
		sc=new Scanner(System.in);
	}
	
	
	public void display() throws SQLException, IdNotFoundException, CustomerNotFoundException
	{
		String ch="y";
		
		while(ch.equals("y"))
		{
			System.out.println("Enter choice:");
			System.out.println("1. insert items:");
			System.out.println("2. insert customer:");
			System.out.println("3. insert purchase details:");
			System.out.println("4. view item details.");
			System.out.println("5. view customer details.");
			System.out.println("6. view purchase details.");
			System.out.println("7. view customer details by id.");
			System.out.println("8.view purchase details by id.");
			System.out.println("9. concession price of item.");
			System.out.println("9. exit");
			int choice1=sc.nextInt();
			
			
			switch(choice1)
			{
			case 1:
				is.StoreItemDetails();
			
				break;
			case 2:
				cs.storeCustomerDetails();
				break;
			case 3:
				ps.purchaseDetails();
				break;
			case 4:
				is.retrieveDetails();
				break;
			case 5:cs.retriveCustomer();
				break;
			case 6:ps.retrievePurchase();
				break;
			case 7:
				cs.retrieveCustomerById("c0002");
				break;
			case 8:
				ps.retrievePurchaseById("c0002");
				break;
			case 9:
				is.calculateConcession("i0001");
				break;
			case 10:
				System.exit(0);
				
			}
			
			System.out.println("do u want to continue(y/n):");
			 ch=sc.next();
		}
	}

}
