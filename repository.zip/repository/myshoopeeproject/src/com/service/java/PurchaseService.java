package com.service.java;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import com.connect.java.DataConnect;

public class PurchaseService {
	private Connection con;
	private PreparedStatement stmt;
	
	private Scanner Sc;
	
	public PurchaseService()
	{
		con=DataConnect.getConnect();
		Sc=new Scanner(System.in);
	}
	
	
	public void purchaseDetails() throws SQLException
	{
		System.out.println("Enter how many details u want to add:");
		int noofpurchase=Sc.nextInt();
		stmt=con.prepareStatement("insert into purchase values(?,?,?,?,?)");
		for(int i=0;i<noofpurchase;i++)
		{
			System.out.println("Enter transaction id: ");
			stmt.setString(1, Sc.next());
			System.out.println("Enter customer code: ");
			stmt.setString(2, Sc.next());
			System.out.println("Enter item code:");
			stmt.setString(3, Sc.next());
			System.out.println("Enter date of purchase: ");
			stmt.setString(4, Sc.next());
			System.out.println("Enter quantity :");
			stmt.setInt(5, Sc.nextInt());
		
		int result=stmt.executeUpdate();
		if(result>0)
		{
			System.out.println("purchase details inserted");
		}
		else
		{
			System.out.println("purchase details failed.");
		}
		}
		
		
		
	}
	
	public void retrievePurchase() throws SQLException,IdNotFoundException
	{
		stmt=con.prepareStatement("select * from purchase");
		ResultSet rs=stmt.executeQuery();
		
		while(rs.next())
		{
			System.out.println("transaction id is:" +rs.getString(1) );
			System.out.println("customer code is:" + rs.getString(2));
			System.out.println("item code is:" +rs.getString(3) );
			System.out.println("date of purchase is:" + rs.getString(4));
			System.out.println("quantity is:" + rs.getInt(5));
		}
	}
	public void retrievePurchaseById(String cid) throws SQLException, IdNotFoundException
	{
		try {
		stmt=con.prepareStatement("select c.cust_name,i.item_name,p.quantity_pur from purchase p join item i join customer c on c.cust_code=p.cust_code and p.item_code=i.item_code  where p.cust_code='"+cid+"'" );
		ResultSet rs=stmt.executeQuery();
		if(rs.next())
		{
			System.out.println("customer name:" + rs.getString(1));
			System.out.println("item name:" + rs.getString(2));
			System.out.println("quantity on hand:" +rs.getInt(3));
		}
		}
		catch(Exception e)
		{
		throw new IdNotFoundException();	
		}
		
	}

}
