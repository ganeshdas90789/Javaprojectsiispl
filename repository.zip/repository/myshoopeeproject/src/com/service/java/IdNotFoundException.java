package com.service.java;

public class IdNotFoundException extends Exception {
	public String show()
	{
		return "id not found";
	}

}
