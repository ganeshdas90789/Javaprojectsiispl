package com.service.java;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import com.connect.java.DataConnect;

public class CustomerService {
	
	private Connection con;
	private PreparedStatement stmt;
	
	private Scanner sc;
	
	public CustomerService()
	{
		con=DataConnect.getConnect();
		sc=new Scanner(System.in);
		
	}
	
	public void storeCustomerDetails() throws SQLException
	{
		System.out.println("Enter the no. of customer u want to add:");
		int noofcustomer=sc.nextInt();
		stmt=con.prepareStatement("insert into customer values(?,?,?,?)");
		for(int i=0;i<noofcustomer;i++)
		{
			System.out.println("Enter customer code:");
			stmt.setString(1,sc.next());
			System.out.println("Enter customer name:");
			stmt.setString(2, sc.next());
			System.out.println("Enter customer phno:");
			stmt.setString(3, sc.next());
			System.out.println("Enter address:");
			stmt.setString(4, sc.next());
		
		int result=stmt.executeUpdate();
		if(result>0)
		{
			System.out.println("customer details inserted");
		}
		else
		{
			System.out.println("customer details not inserted");
		}
		}
	}
	
	public void retriveCustomer() throws SQLException
	{
		
		stmt=con.prepareStatement("select * from customer");
		ResultSet rs=stmt.executeQuery();
		
		while(rs.next())
		{
			System.out.println("customer code:" + rs.getString(1));
			System.out.println("customer name:" + rs.getString(2));
			System.out.println(" phone nnumber:" + rs.getString(3));
			System.out.println("address is:"+ rs.getString(4));
		}
		
	}
	
	public void retrieveCustomerById(String cid) throws SQLException,CustomerNotFoundException
	{
		try {
		stmt=con.prepareStatement("select cust_name,phno,address from customer where cust_code=?");
		stmt.setString(1, cid);
		ResultSet result=stmt.executeQuery();
		if(result.next())

		{
			
			System.out.println("custmer name is"+ result.getString(1));
			System.out.println("custmer phno is"+ result.getString(2));
			System.out.println("custmer address is"+ result.getString(3));


			
			
		}
		}catch(Exception e)
		{
			throw new CustomerNotFoundException();
		}
	}
	
	

}
