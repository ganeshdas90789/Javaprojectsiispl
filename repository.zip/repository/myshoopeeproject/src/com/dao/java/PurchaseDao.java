package com.dao.java;

import java.sql.SQLException;

import com.service.java.IdNotFoundException;
import com.service.java.PurchaseService;

public class PurchaseDao {
	
	private PurchaseService ps;
	
	public PurchaseDao()
	{
		ps=new PurchaseService();
	}
	
	public void insertPurchase() throws SQLException
	{
		ps.purchaseDetails();
	}
	
	public void displayPurchase() throws SQLException, IdNotFoundException
	{
		ps.retrievePurchase();
	}
	public void displaybyid() throws SQLException, IdNotFoundException
	{
		ps.retrievePurchaseById("c0002");
	}
	

}
