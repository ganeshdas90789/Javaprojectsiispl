package com.dao.java;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;

import com.connect.java.DataConnect;
import com.service.java.ItemService;

public class ItemDao {
	
	private Connection con;
	private Scanner Sc;
	
	public ItemService is;
	
	public ItemDao()
	{
		con=DataConnect.getConnect();
		Sc=new Scanner(System.in);
		is=new ItemService();
	}
	
	public void insert() throws SQLException
	{
		is.StoreItemDetails();
	}
	public void display1() throws SQLException
	{
		is.retrieveDetails();
	}
	public void display2() throws SQLException
	{
		is.calculateConcession("i0001");
	}

}
