package com.features.java;
@FunctionalInterface
public interface BankAccount {
	public int calculateInterest(int amount);
	

}
