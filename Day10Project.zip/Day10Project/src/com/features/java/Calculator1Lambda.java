package com.features.java;

public class Calculator1Lambda {
	
	public void display()
	{
		Calculator1 add=(num1,num2)->
		{
			return num1+num2;
			
		};
		int total=add.calculate(50, 70);
		System.out.println("total is" + total);
		
		Calculator1 sub=(x,y)->
		{
			return x-y;
		};
		int diff=sub.calculate(60, 30);
		
	System.out.println("diff is" + diff);
	}
	
	public static void main(String args[])
	{
		Calculator1Lambda c1=new Calculator1Lambda();
		c1.display();
	}

}
