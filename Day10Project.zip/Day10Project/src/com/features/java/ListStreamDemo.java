package com.features.java;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

public class ListStreamDemo {
	
	public static void main(String args[])
	{
		List<Integer> numberlist=Arrays.asList(12,34,56,45,23,100);
		
		System.out.println("in old way");
		numberlist.forEach(num->
		
				
		{
			if(num>50)
			{
				System.out.println("valid number");
			}
		}
				);
		
		numberlist.stream().filter(num->num>50).forEach(s->
		
				
		{
			System.out.println("Number greater than 50 is " + s);
		}
				);
		
		numberlist.stream().map(val->val*2).forEach(newval->
		
				
		{
			System.out.println("value after multiplying is " + newval);
		}
				);
		
		long result=numberlist.stream().filter(num->num>50).count();
		System.out.println(result);
		
		Optional<Integer> data=numberlist.stream().filter(x->x>50).findFirst();
		
		if(data.isPresent())
		{
			System.out.println(data.get());
		}
		List<String> javadevelopers=Arrays.asList("john","Weilly","Vansh","harshita");
		List<String> netdevelopers=Arrays.asList("Anderson","ganesha","anjali");
		List<List<String>> newlist=Arrays.asList(javadevelopers,netdevelopers);
		System.out.println("List is" + newlist);
		List<String> mergelist=newlist.stream().flatMap(val->val.stream()).collect(Collectors.toList());
		System.out.println(mergelist);
		Map<Integer,String>mapd=new HashMap<Integer,String> ();
		mapd.put(101, "java");
		mapd.put(102, "spring");
		mapd.put(103, "hibernate");
		mapd.put(104, "collection");
		mapd.put(105, "eclipse");
		
		mapd.entrySet().stream().filter(dat->dat.getKey()==104).forEach(s->
		
				
		{
			System.out.println(s.getValue());
		}
				);
		
		
		
		
		
		
		
	}

}
