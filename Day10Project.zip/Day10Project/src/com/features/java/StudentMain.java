package com.features.java;

import java.util.LinkedList;
import java.util.List;

public class StudentMain {
	
	private List<Student>stdlist;
	
	public StudentMain()
	{
		stdlist=new LinkedList<Student>();
	}
	
	public void insert()
	{
		Student s1=new Student(1,"ganesha",89);
		Student s2=new Student(2,"Ramesha",87);
		Student s3=new Student(3,"rajib",66);
		
		stdlist.add(s1);
		stdlist.add(s2);
		stdlist.add(s3);
	}
	public void display()
	{
		stdlist.forEach(str->
		
		{
			System.out.println(str.getStudentid());
			System.out.println(str.getStudentname());
			System.out.println(str.getScore());
		}
				);
	}
	double total=0;
	
	public void calculate()
	{
	
		stdlist.forEach(str1->
		
				{
					total=total+str1.getScore();
				
				}
				
				);
		System.out.println("total" + total);
	}
	
	public static void main(String args[])
	{
		StudentMain st=new StudentMain();
		st.insert();
		st.display();
		st.calculate();
		}

}
