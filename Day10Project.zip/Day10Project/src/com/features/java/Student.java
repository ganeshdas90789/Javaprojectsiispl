package com.features.java;

public class Student {
	private int studentid;
	private String studentname;
	private int score;
	public int getStudentid() {
		return studentid;
	}
	public void setStudentid(int studentid) {
		this.studentid = studentid;
	}
	public String getStudentname() {
		return studentname;
	}
	public void setStudentname(String studentname) {
		this.studentname = studentname;
	}
	public int getScore() {
		return score;
	}
	public void setScore(int score) {
		this.score = score;
	}
	
	public Student()
	{
		
	}
	
	public Student(int id,String name,int score)
	{
		this.studentid=id;
		this.studentname=name;
		this.score=score;
	}

}
