package com.features.java;
@FunctionalInterface
public interface Greeting {
	public void greet();
	

}
