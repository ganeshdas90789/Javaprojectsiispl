package com.features.java;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class MovieMain {
	
	private Scanner sc;
	
	private List<Movie> movielist;
	
	public MovieMain()
	{
		sc=new Scanner(System.in);
		movielist=new ArrayList<Movie>();
		
	}
	
	public void acceptDetails()
	{
		System.out.println("Enter no. of movies:");
		int noofmovies=sc.nextInt();
		for(int i=0;i<noofmovies;i++)
		{
			Movie m=new Movie();
			System.out.println("Enter movie number:");
			m.setMovieno(sc.nextInt());
			System.out.println("enter movie name:");
			m.setMovietitle(sc.next());
			System.out.println("Enter category:");
			m.setCategory(sc.next());
			System.out.println("Enter movie duration:");
			m.setDuration(sc.nextInt());
			movielist.add(m);
			System.out.println("Enter movie price");
			m.setPrice(sc.nextDouble());
		}
	}
	public void filterByPrice()
	{
		movielist.stream().filter(movieobj->movieobj.getPrice()>500).forEach(t->
		
		{
			System.out.println(t.getMovietitle());
		}
				);
	}
	
	public void filterByCategoory()
	{
		
		System.out.println("Enter category:");
		String cat=sc.next();
		movielist.stream().filter(move->move.getCategory().equals(cat)).forEach(data->
		
		{
			System.out.println(data.getMovietitle());
			System.out.println(data.getMovieno());
		}
				
				);
	}

	
		
	
	
	
	
	public static void main(String args[])
	{
		MovieMain m1=new MovieMain();
		m1.acceptDetails();
		m1.filterByPrice();
		m1.filterByCategoory();
		
	}
	

}
