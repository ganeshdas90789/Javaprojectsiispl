package com.features.java;

@FunctionalInterface
public interface Calculator {
	
	public void calculate();

}
