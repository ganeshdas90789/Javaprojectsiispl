package com.features.java;

public class WelcomeDemo {
	
	public void display()
	{
	
	Calculator c1=new Calculator()
			{
		public void calculate()
		{
			System.out.println("This method is calculate.");
		}
			};
			c1.calculate();
			
		Calculator c2=new Calculator()
				{
			public void calculate()
			{
				System.out.println("Another implementation of calculate.");
			}
				};
				c2.calculate();
	}
	
	public static void main(String args[])
	{
		WelcomeDemo d1=new WelcomeDemo();
		d1.display();
	}

}
