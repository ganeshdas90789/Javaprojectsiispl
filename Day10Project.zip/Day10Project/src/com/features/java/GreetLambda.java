package com.features.java;

public class GreetLambda {
	
	public void show()
	{
		Greeting g1=()->
		{
			System.out.println("GoodMorning");
		};
		g1.greet();
		
		Greeting g2=()->
		{
			System.out.println("Happybirthday");
		};
		g2.greet();
		
		Greeting g3=()->
		{
			System.out.println("Good evening");
		};
		g3.greet();
		
	}
	
	public static void main(String args[])
	{
		GreetLambda g=new GreetLambda();
		g.show();
	}
	

}
