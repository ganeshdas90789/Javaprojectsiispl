package com.features.java;

public class BankAccountLambda {
	
	double interest=0;
	double interest1=0;
	public void show()
	{
		BankAccount b1=(num)->
		{
			System.out.println("for saving");
			
		   interest=(int) (num*0.07);
		   return (int) interest;
			
			
		};
		b1.calculateInterest(500);
		
		BankAccount b2=(num1)->
		{
			
			System.out.println("for current");
			interest1=(int )(num1*0.05);
			return (int) interest1;
		};
		b2.calculateInterest(700);
	}
	public static void main(String args[])
	{
		BankAccountLambda g1=new BankAccountLambda();
		g1.show();
	}

}
