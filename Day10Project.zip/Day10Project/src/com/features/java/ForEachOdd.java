package com.features.java;

import java.util.ArrayList;
import java.util.List;

public class ForEachOdd {
	
	private List<Integer>liststr;
	
	public ForEachOdd()
	{
		liststr=new ArrayList<Integer>();
	}
	
	public void insert()
	{
		liststr.add(1);
		liststr.add(2);
		liststr.add(3);
		liststr.add(4);
		liststr.add(5);
		
	}
	
	public void check()
	{
		liststr.forEach(str->
		
				
		{
			if(str%2==0)
			{
				
				System.out.println("even" + str);
			}
			else
			{
				System.out.println("odd" + str);
			}
		}
				);
	}
	
	public static void main(String args[])
	{
		ForEachOdd o1=new ForEachOdd();
		o1.insert();
		o1.check();
	}

}
