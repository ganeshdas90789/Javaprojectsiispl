package com.features.java;

import java.util.ArrayList;
import java.util.List;

public class ForEachDemo {
	
	private List<String> liststr;
	
	
	public ForEachDemo()
	{
		liststr=new ArrayList<String>();
	}
	
	public void insert()
	{
		liststr.add("ganesh");
		liststr.add("ramesha");
		liststr.add("ravi");
		liststr.add("kishankuar");
	}
	
	public void display()
	{
		liststr.forEach(s->
		
				{
					System.out.println(s);
				});
	
	}
	
	public void calculateLength()
	{
		liststr.forEach(str->
		
				{
					if(str.length()>5 && str.length()<10)
					{
						System.out.println("valid");
					}
					else
					{
						System.out.println("not valid");
					}
					
				});
		
	}
	
	
	public static void main(String args[])
	{
		ForEachDemo d1=new ForEachDemo();
		d1.insert();
		d1.calculateLength();
		d1.display();
		
	}

}
