package com.features.java;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class UserMain {
	
	private Scanner sc;
	private List<User> userlist;
	
	public UserMain()
	{
		sc=new Scanner(System.in);
		
		userlist=new ArrayList<User>();
	}
	
	public void accept()
	{
		System.out.println("enter no. of user");
		int noofuser=sc.nextInt();
		
		
		for(int i=0;i<noofuser;i++)
		{
			User u1=new User();
			System.out.println("Enter user name:");
			u1.setUsername(sc.next());
			System.out.println("Enter password:");
			u1.setPassword(sc.next());
			userlist.add(u1);
			
			
		}
	}
	
	
	public void check()
	{
		System.out.println("Enter username:");
		String user=sc.next();
	System.out.println("Enter password:");
	String pass=sc.next();
	
	//userlist.stream().allMatch(match->
	//match.getUsername().equals(username) && match.getPassword().equals(password));
	
	
	
	boolean ch=userlist.stream().allMatch(n->n.getUsername().equals(user)&&(n.getPassword().equals(pass)));
			
			if(ch)
			{
				System.out.println("valid");
			}
			else
			{
				System.out.println("invalid");
			}
	}
	
	public static void main(String args[])
	{
		UserMain u1=new UserMain();
		u1.accept();
		u1.check();
		
	}
	

}
