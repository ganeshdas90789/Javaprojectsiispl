package com.features.java;

import java.util.Arrays;
import java.util.List;

public class Odd {
	public static void main(String args[])
	{
	
	List<Integer> numlist=Arrays.asList(1,2,3,4,5);
	numlist.stream().filter(str->str%2==0).forEach(s->
	
	{
		//System.out.println("even" + s);
		System.out.println("odd" +s);
		
		
	}
			);
	
	
	
	
	}
}
