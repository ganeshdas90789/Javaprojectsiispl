package com.features.java;
@FunctionalInterface
public interface Calculator1 {
	
	public int calculate(int x,int y);

}
