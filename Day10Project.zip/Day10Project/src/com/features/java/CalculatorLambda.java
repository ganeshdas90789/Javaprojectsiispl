package com.features.java;

public class CalculatorLambda {
	public void show()
	{
		Calculator c1=()->
		{
			System.out.println("this is  first implementation");
		};
		c1.calculate();
		
		
		Calculator c2=()->
		{
			System.out.println("this is second implementation");
		};
		c2.calculate();
	}
	
	public static void main(String args[])
	{
		CalculatorLambda cm=new CalculatorLambda();
		cm.show();
	}
	

}
