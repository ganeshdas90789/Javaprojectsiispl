package com.features.java;

import java.util.Comparator;

public class SortByComparator implements Comparator<Movie>{

	@Override
	public int  compare(Movie o1, Movie o2) {
		// TODO Auto-generated method stub
		
		return (o1.getMovietitle().compareTo(o2.getMovietitle()));
	}

}
