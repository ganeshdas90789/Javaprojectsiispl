package com.main.java;

import java.sql.SQLException;

import com.menu.java.Menu;
import com.service.java.CustomerNotFoundException;
import com.service.java.IdNotFoundException;

public class AppMain {
	public static void main(String args[]) throws IdNotFoundException, CustomerNotFoundException
	{
	Menu m1=new Menu();
	try {
		m1.display();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	}
	
	

}
