package com.dao.java;

import java.sql.SQLException;

import com.service.java.CustomerNotFoundException;
import com.service.java.CustomerService;

public class CustomerDao {

	
	private CustomerService cs;
	
	public CustomerDao()
	{
		cs=new CustomerService();
	}
	
	public void insertCust() throws SQLException
	{
		cs.storeCustomerDetails();
	}
	public void displayDetails() throws SQLException
	{
		cs.retriveCustomer();
	}
	public void showCust() throws SQLException, CustomerNotFoundException
	{
		cs.retrieveCustomerById("c0002");
	}
}
