package com.service.java;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Scanner;

import com.connect.java.DataConnect;

public class ItemService {
	
	private Connection con;
	private PreparedStatement stmt;
	private CallableStatement stat;
	private Scanner sc;
	
	public ItemService()
	{
		con=DataConnect.getConnect();
		sc=new Scanner(System.in);
	}
	
	public void StoreItemDetails() throws SQLException
	{
		System.out.println("Enter no. of items u want: ");
		int noofitems=sc.nextInt();
		stmt=con.prepareStatement("insert into item  values(?,?,?,?)");
		for(int i=0;i<noofitems;i++)
		{
			System.out.println("Enter item code:");
			stmt.setString(1, sc.next());
			System.out.println("Enter item name:");
			stmt.setString(2, sc.next());
			System.out.println("enter item price:");
			stmt.setInt(3,sc.nextInt());
			System.out.println("enter qoh:");
			stmt.setInt(4, sc.nextInt());
		
		int result=stmt.executeUpdate();
		if(result>0)
		{
			System.out.println(" item Data inserted successfully.");
		}
		else
		{
			System.out.println("item data not inserted.");
		}
		}
		
		
	}
	
	public void retrieveDetails() throws SQLException
	{
		stmt=con.prepareStatement("select * from item");
		ResultSet result=stmt.executeQuery();
		while(result.next())
		{
			System.out.println("item code is:" + result.getString(1));
			System.out.println("item name is:" + result.getString(2));
			System.out.println("price is:" + result.getInt(3));
			System.out.println("quantity on hand:"+ result.getInt(4));
		}
	}
	public void calculateConcession(String itemcode) throws SQLException
	{
		
		stat=con.prepareCall("{ call consession8(?,?)}");
		stat.setString(1, itemcode);
		stat.registerOutParameter(2, Types.INTEGER);
		
		stat.executeUpdate();
		int concession_price=stat.getInt(2);
		stmt=con.prepareStatement("select * from item where item_code=?");
		stmt.setString(1, itemcode);
		ResultSet result=stmt.executeQuery();
		while(result.next())
		{
			System.out.println("item code:" +result.getString(1) );
			System.out.println("item name:" + result.getString(2));
			System.out.println("item price:" + result.getInt(3));
			
		}
		System.out.println("concesson price is:"+concession_price);
		
		
		
	}
	

}
