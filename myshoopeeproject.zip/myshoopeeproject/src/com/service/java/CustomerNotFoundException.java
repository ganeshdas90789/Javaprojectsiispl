package com.service.java;

public class CustomerNotFoundException extends Exception {
	public String show1()
	{
		return"customer not found";
	}

}
