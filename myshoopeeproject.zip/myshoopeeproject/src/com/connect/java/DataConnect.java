package com.connect.java;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DataConnect {
	
	private static Connection con;
	
	public DataConnect()
	{
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/ganesha","root","Ganesha@123");
			System.out.println("connected");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public static Connection getConnect()
	{
		DataConnect d=new DataConnect();
		return con;
		
	}
	
	public static void main(String args[])
	{
		getConnect();
	}

}
