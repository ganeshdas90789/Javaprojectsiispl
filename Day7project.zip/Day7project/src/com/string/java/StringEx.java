package com.string.java;

public class StringEx {
	public static void main(String args[])
	{
	
	String str="Welcome to Java World";
	char ch=str.charAt(5);
	System.out.println(ch);
	 String str1=str.concat("-Let us learn");
	 System.out.println(str1);
	 int position=str.indexOf('a');
	 System.out.println(position);
	 String str2=str.replace('a', 'e');
	 System.out.println(str2);
	 String str3=str.substring(4, 10);
	 System.out.println(str3);
	 String str4=str.toLowerCase();
	 System.out.println(str4);
	 
	 
	 StringBuffer str5=new StringBuffer("This is StringBuffer");
	 StringBuffer  str6=str5.append("-This is a sample program");
	 System.out.println(str6);
	 StringBuffer str7=str5.insert(21, "Object");
	 System.out.println(str7);
	 StringBuffer str8=str5.reverse();
	 System.out.println(str5);
	 StringBuffer str9=str5.replace(14, 20, "Builder");
	 System.out.println(str9);
	
	}
	

}
