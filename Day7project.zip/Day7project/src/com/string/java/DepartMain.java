package com.string.java;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class DepartMain {
	private Department deptmain;
	private List<Employee> emplist;
	private Scanner sc;
	public DepartMain()
	{
		sc=new Scanner(System.in);
		emplist=new ArrayList<Employee>();
		deptmain=new Department();
		
	}
	public void accept()
	{
		System.out.println("Enter department code:");
		deptmain.setDeptcode(sc.nextInt());
		System.out.println("Enter department name:");
		deptmain.setDeptName(sc.next());
		System.out.println("Enter how many employees u want :");
	     int noofemployee=sc.nextInt();
	     
	     for(int x=1;x<=noofemployee;x++)
	     {
	    	 Employee e=new Employee();
	    	 System.out.println("Enter empid:");
	    	 e.setEmpid(sc.nextInt());
	    	 System.out.println("Enter empname:");
	    	 e.setEmpname(sc.next());
	    	 System.out.println("Enter salary:");
	    	 e.setSalary(sc.nextDouble());
	    	 emplist.add(e);
	     }
	     deptmain.setEmplist(emplist);
	     
	}
	public void display()
	{
		
		System.out.println("department code is" + deptmain.getDeptcode());
		System.out.println("department name is" + deptmain.getDeptName());
         List<Employee> elist=deptmain.getEmplist();
         
         for(Employee e:elist)
         {
        	 System.out.println("Employee name is" + e.getEmpname());
         }


	}
	public static void main(String args[])
	{
		DepartMain d1=new DepartMain();
		d1.accept();
		d1.display();

		
	}
	
	
	
	
	
	

}
