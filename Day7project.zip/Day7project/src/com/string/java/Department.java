package com.string.java;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Department {
	private int deptcode;
	private String deptName;
	
	public int getDeptcode() {
		return deptcode;
	}

	public void setDeptcode(int deptcode) {
		this.deptcode = deptcode;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	public List<Employee> getEmplist() {
		return emplist;
	}

	public void setEmplist(List<Employee> emplist) {
		this.emplist = emplist;
	}
	private List<Employee>emplist;
	
	Scanner sc;
	

	

		

	
	
	
	

}
