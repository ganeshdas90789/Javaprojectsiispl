package com.string.java;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class StudentInfo {
	private List<Student> studentlist;
	Scanner sc;
 public StudentInfo()
 {
	 studentlist =new ArrayList<Student>();
	 sc=new Scanner(System.in);
	
	 
 }
 
 
 public void acceptDetails()
 {
	 
	 System.out.println("Enter no. of students:");
	 int noofstudents=sc.nextInt();
	 
	 for(int i=0;i<noofstudents;i++)
	 {
		 Student s1=new Student();
		 System.out.println("Enter student code:");
		 s1.setStudentid(sc.nextInt());
		 System.out.println("Enter student Name:");
		 s1.setStudentname(sc.next());
		 System.out.println("Enter student score:");
		 s1.setScore(sc.nextInt());
		 studentlist.add(s1);
		 
		 
		 
		 
	 }
 }
	 
	 public void findByStudentid()
	 {
		 System.out.println("Enter the studentid :");
		 int studentid=sc.nextInt();
		 
		 boolean found=false;
		 for(Student s:studentlist)
		 {
			 
			 if(studentid==s.getStudentid())
			 {
				 found=true;
			 }
			 else
			 {
				 found=false;
			 }
		 }
		
		 if(found)
		 {
			 System.out.println("found");
		 }
		 else
		 {
			 System.out.println("not found");
		 }
		 	 
	 
 }
	 
	 
	 public void update()
	 {
		 System.out.println("Enter the studentid :");
		 int studentid=sc.nextInt();
		 
		 boolean found=false;
		 for(Student s:studentlist)
		 {
			 
			 if(studentid==s.getStudentid())
			 {
				 s.setScore(90);
				 System.out.println("updated Score " + s.getScore());
			 }
			 /*else
			 {
			 System.out.println("not found");
				 
			 }*/
			 
		 }
		 }
	 
	 public void delete()
	 {
		 
		 Student deletestudent=null;
		 System.out.println("Enter the studentid :");
		 
		 int studentid=sc.nextInt();
		 
		 for(Student s:studentlist)
		 {
			 
			 if(studentid==s.getStudentid())
			 {
				 deletestudent=s;
				 break;
				 
			 }
			 if(deletestudent!=null)
			 {
			  studentlist.remove(deletestudent);
			 }
		 }
		
		 
		 	
	 }
	 
	 public void display()
	 {
		 for(Student s:studentlist)
		 {
			 System.out.println("Student id is:"+ s.getStudentid());
			 System.out.println("Student name is:" + s.getStudentname());
			 System.out.println("Score is:" + s.getScore());
		 }
	 }
 
 
 
 
 
 
 
 public static void main(String args[])
 {
	 StudentInfo s2=new StudentInfo();
	 s2.acceptDetails();
	 s2.display();
	 s2.findByStudentid();
	 s2.update();
	 s2.delete();
	 
 }
}
