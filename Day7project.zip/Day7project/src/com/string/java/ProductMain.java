package com.string.java;

public class ProductMain {
	public static void main(String args[])
	{
		Product product1=new Product();
		product1.setProductId(1);
		product1.setProductName("mouse");
		product1.setProductPrice(900);
		
		Product p1=new Product();
		p1.setProductId(1);
		p1.setProductName("mouse");
		p1.setProductPrice(900);
		
		if(product1.equals(p1))
		{
			System.out.println("they are equal");
		}
		else
		{
			System.out.println("they are not equal");
		}
		
		
	}

}
