package com.string.java;

import java.util.ArrayList;
import java.util.List;

public class ListDemo {
	
	private List<String> liststr;
	public ListDemo()
	{
		liststr=new ArrayList<String>();
		liststr.add("welcome");
		liststr.add("ganesh");
		liststr.add("hello");
		liststr.add("spring");
		System.out.println("Removing data");
		liststr.remove("hello");
		if(liststr.contains("spring"))
		{
			System.out.println("in list");
		}
		else
		{
			System.out.println("not in list");
		}
		
		
	}
		public void show()
		{
			for(String str:liststr)
			{
				System.out.println(str);
				
			}
		}
		
		
		public static void main(String args[])
		{
			ListDemo st=new ListDemo();
					
				st.show();
					
		}
	}
	


