package com.abstrac.java;

public abstract class Bank {
	
	public abstract double getBalance();

}
