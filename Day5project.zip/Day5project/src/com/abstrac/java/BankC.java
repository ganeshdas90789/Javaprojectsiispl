package com.abstrac.java;

public class BankC extends Bank{
	
	public double getBalance()
	{
		double money=0;
		return money=money+300;
	}

}
