package com.abstrac.java;

public abstract class Marks {
	
	public abstract double getPercentage();
	
		
	

}
