package com.abstrac.java;

public class child1 extends Parent {
	
	public void message()
	{
		System.out.println("This is first subclass.");
	}

}
