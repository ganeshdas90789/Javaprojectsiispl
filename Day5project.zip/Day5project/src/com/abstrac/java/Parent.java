package com.abstrac.java;

public abstract class Parent {
	
	public abstract void message();

}
