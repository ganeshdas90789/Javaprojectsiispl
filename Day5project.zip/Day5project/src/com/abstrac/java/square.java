package com.abstrac.java;

public class square extends Reactangle {
	
	
	public void getArea()
	{
		
	}
	public void getPerimeter()

	{
		
		
	}
	
	

}
