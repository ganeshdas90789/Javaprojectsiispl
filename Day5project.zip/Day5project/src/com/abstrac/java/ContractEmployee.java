package com.abstrac.java;

public class ContractEmployee extends Employee{
	
	private double contractPeriod;
	private double contractAmount;
	
	public void accept()
	{
		super.accept();
		System.out.println("Enter contract amount:");
		contractAmount=Sc.nextDouble();
		{
		System.out.println("Enter contract Period:");
		contractPeriod=Sc.nextDouble();
		}
		
	}
	public void display()
	{
		super.display();
		System.out.println("contract amount is" + contractAmount);
		System.out.println("Contract Period is" + contractPeriod);
		
	}
	
	public void calculateSalary()
	{
		double Salary=contractPeriod*contractAmount;
		System.out.println("Updated salary is" + Salary);
	}



}
