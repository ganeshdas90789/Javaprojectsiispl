package com.abstrac.java;

public class Circle extends shape {

	@Override
	void getArea() {
		// TODO Auto-generated method stub
		
	}

	@Override
	void getPerimeter() {
		// TODO Auto-generated method stub
		
	}

}
