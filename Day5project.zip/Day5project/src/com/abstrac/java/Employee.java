package com.abstrac.java;

import java.util.Scanner;

public abstract class Employee {
	private int empid;
	private String empname;
	protected Scanner Sc;
	
	
	public Employee()
	{
		Sc=new Scanner(System.in);
		
	}
	
	public void accept()
	{
		System.out.println("Enter the empid:");
		empid=Sc.nextInt();
		System.out.println("Enter the empname:");
		empname=Sc.next();
	}
	
	public void display()
	{
		System.out.println("Empid is: " + empid);
		System.out.println("Empname is:" + empname);
	}
	
	public abstract void calculateSalary();
	
		
	

}
