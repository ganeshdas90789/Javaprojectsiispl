package com.abstrac.java;

public class Reactangle extends shape {

	@Override
	void getArea() {
		// TODO Auto-generated method stub
		
	}

	@Override
	void getPerimeter() {
		// TODO Auto-generated method stub
		
	}

}
