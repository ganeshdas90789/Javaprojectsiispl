package com.abstrac.java;

public class classA extends Marks {
	int sub1;
	int sub2;
	int sub3;
	
	public classA(int sub1,int sub2,int sub3)
	{
		this.sub1=sub1;
		this.sub2=sub2;
		this.sub3=sub3;
		
	}
	
	public double getPercentage()
	{
		double total=sub1+sub2+sub3;
		double percentage=(total/300)*100;
		return percentage;
	}

}
