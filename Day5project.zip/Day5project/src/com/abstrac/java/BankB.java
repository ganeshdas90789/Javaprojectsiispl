package com.abstrac.java;

public class BankB extends BankC {
	
	public double getBalance()
	{
		double money=0;
		return money=money+200;
	}

}
