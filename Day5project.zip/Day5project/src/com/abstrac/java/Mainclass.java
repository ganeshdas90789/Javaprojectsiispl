package com.abstrac.java;

public class Mainclass {
	public static void main(String args[])
	{
		Bank b1=new BankA();
		 System.out.println(b1.getBalance());
		
		Bank b2=new BankB();
		System.out.println(b2.getBalance());
		
		Bank c1=new BankC();
		System.out.println(c1.getBalance());
	}


}
