package com.abstrac.java;

public class PermanentEmployee  extends Employee{
	
	private double Salary;
	public void accept()
	{
		super.accept();
		System.out.println("Enter Salary:");
		Salary=Sc.nextDouble();
	}
	public void display()
	{
		super.display();
		System.out.println("Salary is" + Salary);
	}
	public void calculateSalary()
	{
		Salary=Salary*12;
		System.out.println("Annual salary is" + Salary);
	}
	public void show()
	{
		
	}

}
