package com.abstrac.java;

import java.util.Scanner;

public class AppMain {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		Employee emp1;
		Employee emp2;
		System.out.println("Enter the choice");
		System.out.println("1. Details of Permanent Employee.");
		System.out.println("2.Details of Contact Employee.");
		System.out.println("3. Exit");
		int choice=sc.nextInt();
		switch(choice)
		{
		case 1:
			
			emp1=new PermanentEmployee();
			emp1.accept();
			emp1.display();
			emp1.calculateSalary();
			break;
		case 2:
			
			emp2=new ContractEmployee();
			emp2.accept();
			emp2.display();
			emp2.calculateSalary();
			break;
			
		case 3:
			System.exit(0);
			
			
			
		}
		
		
	
		
		
		
		
		

	}

}
