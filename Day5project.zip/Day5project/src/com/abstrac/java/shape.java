package com.abstrac.java;

public abstract  class shape {
	
	abstract void getArea();
	abstract void getPerimeter();
	
	
	

}
