package com.abstrac.java;

public class classMain {
	
	public static void main(String args[])
	{
	/*arks m1=new classA(20,30,40);
		System.out.println(m1.getPercentage());
		Marks m2=new classB(20,30,40,50);
		System.out.println(m2.getPercentage());*/
		
		classA a=new classA(50,60,90);
		System.out.println(a.getPercentage());
		classB b=new classB(20,30,40,50);
		System.out.println(b.getPercentage());
		
		
		
	}

}
