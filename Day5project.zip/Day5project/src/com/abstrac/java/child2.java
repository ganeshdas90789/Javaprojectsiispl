package com.abstrac.java;

public class child2 extends Parent {
	
	public void message()
	{
		System.out.println("This is second subclass.");
	}

}
