package com.instruent.java;

public class instrument1 implements percussioninstrument,BrassInstrument,StringInstrument{
	
	public static void main(String args[])
	{
		instrument1 t1=new instrument1();
		t1.buzz("buzzing");
		t1.isBroke();
		t1.demo();
		t1.repair();
		t1.instrumentName();
		t1.play(PLAY_MSG);
		t1.hit("hitting");
		t1.shake("shaking");
		t1.bow("bowing");
		t1.pluck("plucking");
		
		
		
		
		
	}
	

	
	@Override
	public void demo() {
		// TODO Auto-generated method stub
		System.out.println("this is children toy");
		
	}

	@Override
	public void buzz(String s) {
		// TODO Auto-generated method stub
		
	  System.out.println(s);
		
		
		
	}

	@Override
	public boolean isBroke() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void repair() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void instrumentName() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void play(String s) {
		// TODO Auto-generated method stub
		System.out.println(s);
		
	}

	@Override
	public void hit(String s) {
		// TODO Auto-generated method stub
		System.out.println(s);
		
	}

	@Override
	public void shake(String s) {
		// TODO Auto-generated method stub
		System.out.println(s);
		
	}

	@Override
	public void bow(String s) {
		// TODO Auto-generated method stub
		System.out.println(s);
		
	}

	@Override
	public void pluck(String s) {
		// TODO Auto-generated method stub
		System.out.println(s);
		
	}

}
