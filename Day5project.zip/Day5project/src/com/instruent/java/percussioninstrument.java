package com.instruent.java;

public interface percussioninstrument extends childrenToy,Musicalinstrument{
	
	//void demo();
	
	void hit(String s);
	
	void shake(String s);
	
	
	

}
