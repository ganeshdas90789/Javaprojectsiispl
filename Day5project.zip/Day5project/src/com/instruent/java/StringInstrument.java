package com.instruent.java;

public interface StringInstrument extends Musicalinstrument {
	
	void bow(String s);
	void pluck(String s);
	

}
