package com.instruent.java;

public interface Musicalinstrument {
	
  String 	PLAY_MSG="Triumph";
  
  boolean isBroke();
  
  void repair();
  
  //void demo();
  
  void instrumentName();
  
  void play(String s);
  
  

}
