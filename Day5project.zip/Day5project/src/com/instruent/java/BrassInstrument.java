package com.instruent.java;

public interface BrassInstrument extends Musicalinstrument {
	
	void buzz(String s);
	

}
