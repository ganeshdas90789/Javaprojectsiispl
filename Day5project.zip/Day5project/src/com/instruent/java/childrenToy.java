package com.instruent.java;

public interface childrenToy {
	
	void demo();

}
