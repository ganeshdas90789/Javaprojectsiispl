package com.inter.java;

public class Employee implements Personaldetails {
	public void acceptName() {
		
		System.out.println("Accepting name of employee.");
	}
	
	public void acceptAddress()
	{
		System.out.println("Accepting the adress of employee.");
	}
	

}
