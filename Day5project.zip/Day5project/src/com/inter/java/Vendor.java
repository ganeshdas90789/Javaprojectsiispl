package com.inter.java;

public class Vendor implements Personaldetails {

	@Override
	public void acceptName() {
		
		System.out.println("Accepting name:");

		
	}

	@Override
	public void acceptAddress() {
		System.out.println("Accepting address:");
		
		
	}
	

}
