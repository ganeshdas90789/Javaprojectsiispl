package com.inter.java;

public interface Personaldetails {
	void acceptName();
	void acceptAddress();
	int x=30;
		
	

}
