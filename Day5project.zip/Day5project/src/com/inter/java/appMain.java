package com.inter.java;

public class appMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Personaldetails pd;
		pd=new Employee();
		pd.acceptName();
		pd.acceptAddress();

	}

}
