package com.age.java;
import java.util.Scanner;

public class KidUsers implements LibraryUser {
	
	int age;
	String bookType;
	
	public KidUsers()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the age:");
		age=sc.nextInt();
		System.out.println("Enter the book type:");
		bookType=sc.next();
		
		
	}

	@Override
	public void registerAccount() {
		
		if(age<12)
		{
			System.out.println("You have successfully registered under the kids account.");
		}
		else
		{
			System.out.println("Sorry Age must be less than 12 to register as a kid.");
		}
	
		
	}

	@Override
	public void requestBook() {
		
		if(bookType.equals("kids"))
		{
			System.out.println("Book issued Successfully please return the book within 10 days.");
		}
		else
		{
			System.out.println("Oops you should allow to take only kids book.");
		}
	
		
	}

}
