package com.age.java;

import java.util.Scanner;

public class AdultUser implements LibraryUser   {
	int age;
	String bookType;
	
	public AdultUser()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the age:");
		age=sc.nextInt();
		System.out.println("Enter the book type:");
		bookType=sc.next();
		
		
	}

	@Override
	public void registerAccount() {
		
		if(age>12)
		{
			System.out.println("You have successfully registered under the Adults account.");
		}
		else
		{
			System.out.println("Sorry Age must be greater than 12 to register as a Adult.");
		}
		
		
	}

	@Override
	public void requestBook() {
	
		
		if(bookType.equals("Fiction"))
		{
			System.out.println("Book issued Successfully please return the book within 7 days.");
		}
		else
		{
			System.out.println("Oops you should allow to take only Adult Fiction book.");
		}
		
	}

}
