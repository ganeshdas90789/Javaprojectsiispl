package com.age.java;

public interface LibraryUser {
	
	void registerAccount();
	void requestBook();
	

}
