package com.age.java;

public class LibraryInterfaceDemo {

	public static void main(String[] args) {
		
		
		KidUsers k1=new KidUsers();
		
		k1.registerAccount();
		
		AdultUser a1=new AdultUser();

	}

}
