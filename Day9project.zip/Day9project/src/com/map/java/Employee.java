package com.map.java;

import java.util.Scanner;

public class Employee {
	private int empid;
	private String empname;
	private double salary;
	private Scanner sc;
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getEmpname() {
		return empname;
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	public double getSalary() {
		return salary;
	}
	public Scanner getSc() {
		return sc;
	}
	public void setSc(Scanner sc) {
		this.sc = sc;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	

}
