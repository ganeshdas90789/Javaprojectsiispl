package com.map.java;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class EmployeeMain {
	public static void main(String args[])
	{
	Set<Employee1> emplist=new TreeSet<Employee1>(new SortByIdComparator());
	Employee1 e1=new Employee1(102,"stts",12000);
	Employee1 e2=new Employee1(101,"ramesh",16000);
	emplist.add(e1);
	emplist.add(e2);
	//Collections.sort(emplist, new SortByNameComparator());
	//Collections.sort(emplist,new SortByIdComparator());
	
	for(Employee1 e:emplist)
	{
		System.out.println("empid" +e.getEmpid());
		System.out.println("empname" +e.getEmpname());
		System.out.println("salary" +e.getSalary());
	}

	
	
	
	}

}
