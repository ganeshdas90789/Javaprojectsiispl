package com.map.java;

import java.util.Comparator;

public class SortByIdComparator implements Comparator<Employee1> {

	@Override
	public int compare(Employee1 o1, Employee1 o2) {
		// TODO Auto-generated method stub
		
		
		//return o1.getEmpid()-o2.getEmpid();
		return Integer.compare(o1.getEmpid(), o2.getEmpid());
	}

}
