package com.map.java;

import java.util.Comparator;

public class SortByNameComparator implements Comparator<Employee1>{

	@Override
	public int compare(Employee1 o1, Employee1 o2) {
		// TODO Auto-generated method stub
		return o1.getEmpname().compareTo(o2.getEmpname());
	}
	

}
