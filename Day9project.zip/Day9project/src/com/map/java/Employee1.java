package com.map.java;

public class Employee1 implements Comparable<Employee1> {
	
	
	private int empid;
	private String empname;
	private double salary;

	public int getEmpid() {
		return empid;
	}

	public void setEmpid(int empid) {
		this.empid = empid;
	}

	public String getEmpname() {
		return empname;
	}

	public void setEmpname(String empname) {
		this.empname = empname;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}
	
	public Employee1()
	{
		
	}
	public Employee1(int empid,String empname,double salary)
	{
		this.empid=empid;
		this.empname=empname;
		this.salary=salary;
	}



	@Override
	public int compareTo(Employee1 o) {
		// TODO Auto-generated method stub
		
		return  this.empid-o.empid;
	}
	
	

}
