package com.map.java;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;

public class MapDemo {
	private Map<Integer,String> mapd;
	private Scanner sc;
	public MapDemo()
	{
		mapd=new HashMap<Integer,String>();
		sc=new Scanner(System.in);
	}
	public void operations()
	{
		mapd.put(1001, "java");
		mapd.put(1002, "Spring");
		mapd.put(1003, "Hibernate");
		mapd.put(1004, "SpringBoot");
		
		System.out.println("retrieve");
		String value=mapd.get(1004);
		System.out.println("Value according to particular key:");
		Set<Map.Entry<Integer,String>> mapdata=mapd.entrySet();
		
		for(Entry<Integer,String> mapd :mapdata)
		{
			System.out.println("key is" + mapd.getKey());
			System.out.println("value is" + mapd.getValue());
			
		}
		
		if(mapd.containsKey(1003))
		{
			System.out.println("true");
		}
		
	}	
		public void insert()
		{
			System.out.println("Enter no, of values :");
			int noofvalues=sc.nextInt();
			
			int intialkey=101;
			sc.nextLine();
			for(int i=0;i<noofvalues;i++)
			{
				System.out.println("Enter values:");
				String value=sc.nextLine();
				
				mapd.put(intialkey, value);
				intialkey=intialkey+1;
				
			}
			
		}
		public void display()
		{
			Set<Map.Entry<Integer,String>> mapdata=mapd.entrySet();
			for(Entry<Integer,String> mapd :mapdata)
			{
				System.out.println("key is" + mapd.getKey());
				System.out.println("value is" + mapd.getValue());
				
			}
			
		}
		
		 
	
	
	public static void main(String args[])
	{
		MapDemo d1=new MapDemo();
		//d1.operations();
		d1.insert();
		d1.display();
	}
	

}
