package com.map.java;

import java.util.Map;
import java.util.Scanner;

public class Department {
	private int deptcode;
	private String deptname;
	private String city;
	private Map<Integer,Employee> employeemap;
	private Scanner sc;
	public int getDeptcode() {
		return deptcode;
	}
	public void setDeptcode(int deptcode) {
		this.deptcode = deptcode;
	}
	public Scanner getSc() {
		return sc;
	}
	public void setSc(Scanner sc) {
		this.sc = sc;
	}
	public String getDeptname() {
		return deptname;
	}
	public void setDeptname(String deptname) {
		this.deptname = deptname;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public Map<Integer, Employee> getEmployeemap() {
		return employeemap;
	}
	public void setEmployeemap(Map<Integer, Employee> employeemap) {
		this.employeemap = employeemap;
	}

}
