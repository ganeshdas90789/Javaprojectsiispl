package com.map.java;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

public class DepartmentMain {
	
	private Scanner sc;
	
	private Map<Integer,Employee> empmap;
	Department deptobj;
	
	public DepartmentMain()
	{
		sc=new Scanner(System.in);
		empmap=new HashMap<>();
		deptobj=new Department();
		
	}
	
	public void insert()
	{
		System.out.println("Enter dept.code:");
		deptobj.setDeptcode(sc.nextInt());
		
		System.out.println("Enter dept.name:");
		deptobj.setDeptname(sc.next());
		
		System.out.println("Enter dept.city:");
		deptobj.setCity(sc.next());
		
		System.out.println("Enter employees:");
		int noofemployees=sc.nextInt();
		
		for(int i=0;i<noofemployees;i++)
		{
			Employee e1=new Employee();
			System.out.println("Enter id:");
			int eid=sc.nextInt();
			e1.setEmpid(eid);
			
			System.out.println("Enter empname:");
			e1.setEmpname(sc.next());
			
			System.out.println("Enter salary:");
			e1.setSalary(sc.nextDouble());
			empmap.put(eid, e1);
		}
		deptobj.setEmployeemap(empmap);
		
		
		
	}
	
	public void display()
	{
		System.out.println("dept code is" + deptobj.getDeptcode());
		System.out.println("dept name is " + deptobj.getDeptname());
		System.out.println("dept city is" + deptobj.getCity());
		
		Map<Integer, Employee> empmap= deptobj.getEmployeemap();
		Set<Map.Entry<Integer, Employee>> empset=empmap.entrySet();
		
		for(Map.Entry<Integer, Employee> mpentry:empset)
		{
			Employee e=mpentry.getValue();
			System.out.println(" empid is:" + e.getEmpid());
			System.out.println("empame is:" + e.getEmpname());
		}
	
		
		
	}
	
	public void calculateSalary()
	{
		Map<Integer, Employee> empmap= deptobj.getEmployeemap();
		Set<Map.Entry<Integer, Employee>> empset=empmap.entrySet();
		double total=0;
		for(Map.Entry<Integer, Employee> mpentry:empset)
		{
			Employee e=mpentry.getValue();
			
			total=total+e.getSalary();
			
		}
		System.out.println("total salary" + total);
		
	}
	public void calculateBonus()
	{
		Map<Integer, Employee> empmap= deptobj.getEmployeemap();
		Set<Map.Entry<Integer, Employee>> empset=empmap.entrySet();
		for(Map.Entry<Integer, Employee> mpentry:empset)
		{
			Employee e=mpentry.getValue();
			if(e.getSalary()>50000 && e.getSalary()<70000)
			{
				double bonus=e.getSalary()*0.2;
				System.out.println("bonus is:" + bonus);
			}
			else if(e.getSalary()>30000 && e.getSalary()<50000)
			{
				double bonus1=e.getSalary()*0.15;
				System.out.println("bonus is" + bonus1);
			}
			else
			{
				double bonus2=e.getSalary()*0.1;
				System.out.println("bonus is "+ bonus2);
			}
		}
		
	}
	
	public static void main(String args[])
	{
		DepartmentMain d1=new DepartmentMain();
		d1.insert();
		d1.display();
		d1.calculateSalary();
		d1.calculateBonus();
	}
	

}
