package com.exception.java;

public class InvalidUserException extends Exception {
	
	public String getMessage()
	{
		return "invalid user login and password";
	}

}
