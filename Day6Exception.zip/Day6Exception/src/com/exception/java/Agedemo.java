package com.exception.java;

import java.util.Scanner;
public class Agedemo {
	
	private Scanner Sc;
	private int age;
	
	public Agedemo()
	{
		Sc=new Scanner(System.in);
		
	}
	
	public void accessAge() throws InvalidAgeException
	{
		System.out.println("enter age");
		age=Sc.nextInt();
		//try {
		//if(age<18)
		//{
			throw new InvalidAgeException();
		//}
		//}
		//catch(InvalidAgeException ex)
		//{
			//System.out.println(ex.getMessage());
		//}
	}
	public static void main(String args[])
	{
		Agedemo a1=new Agedemo();
		
		try {
			a1.accessAge();
		} catch (InvalidAgeException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
			//e.printStackTrace();
		}
	}
	

}
