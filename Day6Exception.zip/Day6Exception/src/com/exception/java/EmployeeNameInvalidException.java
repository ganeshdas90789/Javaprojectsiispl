package com.exception.java;

public class EmployeeNameInvalidException extends Exception {
	
	public String getMessage()
	{
		return "The employee name cant be empty";
	}
	

}
