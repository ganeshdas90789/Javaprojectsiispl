package com.exception.java;

public class ArrayStore {
	
	public static void main(String args[])
	{
		try {
		
			Number arr[]=new Integer[3];
		    arr[0]=new Double(20.4);
		
		    System.out.println(arr[0]);
		}
		
		catch(ArrayStoreException e)
		{
			System.out.println("storing int value in string array");
		}
	}

}
