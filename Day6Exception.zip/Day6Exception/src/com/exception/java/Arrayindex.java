package com.exception.java;

import java.util.Scanner;

public class Arrayindex {
	
	private Scanner sc;
	int arr[]=new int[3];
	
	public Arrayindex()
	{
		sc=new Scanner(System.in);
		
	}
	public void show()
	{
		System.out.println("Enter numbers");
		
		try {
		
			for(int i=0;i<=3;i++)
		{
			arr[i]=sc.nextInt();
		}
	}catch(ArrayIndexOutOfBoundsException  e)
		{
			System.out.println("array index out of bound");
		}
	}
	public void display()
	{
		for(int var:arr)
		{
			System.out.println(var);
		}
	}
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Arrayindex i1=new Arrayindex();
		i1.show();
		i1.display();

	}

}
