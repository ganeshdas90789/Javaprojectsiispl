package com.exception.java;

public class CountryNotValidException extends Exception {
	
	public String getMessage()
	{
		return "The employee should be an indian citizen for calculating tax ";
		
	}

}
