package com.exception.java;

import java.util.Scanner;

public class ArithDemo {
	private Scanner sc;
	int number1,number2;
	public ArithDemo()
	{
		sc=new Scanner(System.in);
		
	}
	public void checkresult()
	{
		System.out.println("Enter a number:");
		number1=sc.nextInt();
		System.out.println("Enter another number:");
		number2=sc.nextInt();
		try 
		{
			double result =number1/number2;
			System.out.println("result is" + result);
			
		}
		catch(ArithmeticException e)
		{
			System.out.println("cant divided by zero");
		}
		System.out.println("welcome toexception handeling");
	}
	public static void main(String args[])
	{
		ArithDemo d1=new ArithDemo();
		d1.checkresult();
	}
	

}
