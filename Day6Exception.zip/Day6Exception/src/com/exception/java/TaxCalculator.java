package com.exception.java;


public class TaxCalculator {
	

	private String empName;
	private boolean isIndian;
	private double empSal;
	
	

	
	
	
	/*public void calculateTax1(String empName,boolean isIndian,double empSal)
	
	
	{
		empName=empName;
		isIndian=isIndian;
		empSal=empSal;
		
	}*/
	public void checkNation(boolean  isIndian) throws CountryNotValidException
	{
		
		if(isIndian==false)
		{
		
			throw new CountryNotValidException();
		}
		
		else {
			
			System.out.println("valid");
		}
	}
	
	
	public void checkName(String empName) throws EmployeeNameInvalidException
	{
		if(empName==null)
		{
			throw new EmployeeNameInvalidException();
		}
		else
		{
			System.out.println("valid ");
		}
	}
	
	public void calculateTax(String empName,boolean isIndian,double empSal) throws TaxNotEligibleException
	{
		
		
		
		if(empSal>100000 && isIndian==true)
		{
			double  taxAmount=(empSal*8)/100;
			System.out.println(taxAmount);
		}
		else if((empSal>50000 && empSal<100000) && isIndian==true)
		{
			double taxAmount=(empSal*6)/100;
			System.out.println(taxAmount);
		}
		else if((empSal>30000 && empSal<50000) && isIndian==true)
		{
			double taxAmount=(empSal*5)/100;
			System.out.println(taxAmount);
		}
		else if((empSal>10000 && empSal<30000) && isIndian==true)
		{
			double taxAmount=(empSal*4)/100;
			System.out.println(taxAmount);
		}
		else
		{
			throw new TaxNotEligibleException();
		}
			
		
	}
	
	
	

}
