package com.exception.java;
import java.util.Scanner;
public class Invalid {
	
	private Scanner Sc;
	int balance=1000;
	String userName="user";
	String Password="Password";
	
	public Invalid()
	{
		Sc=new Scanner(System.in);
		
	}
	
	public void checkAmount() throws InvalidAmountException 
	{
		System.out.println("Enter amount :");
		int amount=Sc.nextInt();
		if(amount<balance)
		{
			System.out.println(balance=balance-amount);
		}
		else
		{
		
		throw new InvalidAmountException();
		}
	}
	
	public void checkUser() throws InvalidUserException
	{
		System.out.println("Enter username:");
		String str=Sc.next();
		System.out.println("Enter password");
		String str2=Sc.next();
		if(str.equals("User") && str2.equals("Password"))
		{
			System.out.println("successsful");
		}
		else
		{
		
		throw new InvalidUserException();
		}
	}
	
	
	public static void main(String args[])
	{
		Invalid i1=new Invalid();
		try {
			i1.checkAmount();
			i1.checkUser();
		} catch (InvalidAmountException e) {
			
		e.printStackTrace();
		
		}
		catch(InvalidUserException e)
		{
			e.printStackTrace();
		}
		
	}

}
