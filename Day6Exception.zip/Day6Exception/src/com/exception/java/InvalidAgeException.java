package com.exception.java;

public class InvalidAgeException extends Exception {
	
	public String getMessage()
	{
		return "trying to enter invalid age";
		
	}

}
