package com.exception.java;

public class TaxNotEligibleException extends Exception {
	
	public String  getMessage()
	{
		return "The employee does not need to pay tax.";
		
	}

}
