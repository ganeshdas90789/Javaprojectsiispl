package com.exception.java;

public class CalculatorSimulator {
	
	public static void main(String args[])
	{
		TaxCalculator t1=new TaxCalculator();
		try {
			t1.checkNation(false);
		} catch (CountryNotValidException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			t1.checkName("Ron");
		} catch (EmployeeNameInvalidException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			t1.calculateTax("Ron", false, 34000);
		} catch (TaxNotEligibleException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}

}

