package com.exception.java;

import java.util.Scanner;

public class MultipleException {
	private Scanner sc;
	String arr[];
	
	public MultipleException()
	{
		sc=new Scanner(System.in);
		arr=new String[4];
	}
	
	public void accept()
	{
		System.out.println("Enter strings:");
		for(int i=0;i<arr.length;i++)
		{
			arr[i]=sc.next();
		}
	}
	
	public void divide()
	{
		try {
		
		System.out.println("Enter the  first String:");
		int number1=Integer.parseInt(arr[0]);
		System.out.println("Enter the index value:");
		int number2=Integer.parseInt(arr[1]);
		int divide=number1/number2;
		System.out.println(divide);
	        }
		catch(NumberFormatException  e)
		{
			System.out.println("number format.");
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("trying to access beyond the limit.");
			
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		

	}
	
	public static void main(String args[])
	{
		MultipleException m1=new MultipleException();
		m1.accept();
		m1.divide();
	}
}
