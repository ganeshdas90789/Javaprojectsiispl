package com.exception.java;

import java.util.Scanner;

public class NumberFormat {
	private Scanner sc;
	
	String str;
	
	public NumberFormat()
	{
		sc=new Scanner(System.in);
		
	}
	
	public void display()
	{
		try {
		System.out.println("Enter house number:");
		str=sc.next();
		
		int number1=Integer.parseInt(str);
		System.out.println(number1);
		}catch(NumberFormatException e)
		{
			System.out.println("number format exception");
		}
	}
	
	public static void main(String args[])
	{
		NumberFormat n1=new NumberFormat();
		n1.display();
	}

}
