package com.exception.java;

public class InvalidAmountException extends Exception {
	public String getMessage()
	{
		return "trying to get amount beyond limit";
	}

}
