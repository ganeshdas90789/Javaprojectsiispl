package com.training.java;

public class calculator {
	public static void main(String args[])
	{
	int a=10;
	int b=20;
	int sum=a+b;
	System.out.println("sum is" + sum);
	boolean result=false;
	System.out.println(result);
	long mobileno=7677777;
	System.out.println(mobileno);
	}

}
